; ==========================================
;  UNSUNGRINDER v1.0 - automation macro for Unsungfield (Roblox)
;  Made by Equinoxiiq  -  questions / inquiries: @equinoxi_q on Discord
; ==========================================
#Requires AutoHotkey v2.0
#SingleInstance Force

AppVersion := "1.0"

CoordMode "Mouse", "Screen"
SendMode "Event"          ; Roblox ignores the default SendInput a lot of the time
SetKeyDelay 40, 20        ; key delay / press duration for SendEvent

; ==========================================
; CONFIGURATION
; ==========================================

; ENTER YOUR CLICK COORDINATES (screen coords - use Window Spy to find them)
; POINT 1 = case open button. F5 cycles between these modes.
OpenModes := [
    {Name: "x1K  $5M",   X: 1138, Y: 549},
    {Name: "x5K  $25M",  X: 1194, Y: 549},
    {Name: "x10K $50M",  X: 1250, Y: 549}
]
OpenModeIndex := 2        ; starting mode (2 = $25M)

Point1 := [OpenModes[OpenModeIndex].X, OpenModes[OpenModeIndex].Y]
Point2 := [960, 741]      ; Results "OK" button
Point3 := [1500, 850]     ; empty ground right of the UI (closes/advances screens)

ClickDelay := 85        ; ms between clicks (was 150)

; M1 LOCK - keeps the melee attack held while menus are open:
;   hold M1 on Point3 -> ESC -> let go -> 0.5s -> ESC
; The game then keeps M1 held until the world is clicked again, so while it's
; locked the Point3 (ground / melee) click is skipped - it would release it.
; Done before the case UI / skill tree open, after deploying, after re-equipping.
UseM1Lock      := true
M1EscDelayMs   := 500         ; wait between letting go of M1 and the 2nd ESC
M1RelockMs     := 0           ; re-do the lock this often as a safety net (0 = off)
CosmeticsRect  := [630, 305, 1290, 775]   ; the Cosmetics (case) window - never hold M1 in here
M1FallbackXY   := [1500, 850]             ; used if Point3 is ever inside that window

; OCR REGION (top-left chat box)
OCR_X := 0
OCR_Y := 105
OCR_W := 440
OCR_H := 265

OCR_Interval  := 3000
Chat_Interval := 30000

ChatMessage := "e"
RobloxExe := "ahk_exe RobloxPlayerBeta.exe"
UserChatTimeout := 20000   ; max ms clicks stay paused after you press / in chat

; OCR ENGINE
;   "windows"   - the OCR built into Windows 10/11. Nothing to install.
;                 Needs an OCR-capable language (English is normally there;
;                 if not: Settings > Time & Language > Language > add English).
;   "tesseract" - optional, only if you have Tesseract installed and prefer it.
OCREngine := "windows"

; Only used when OCREngine = "tesseract". Checked in order.
TesseractPaths := [
    "C:\Program Files\Tesseract-OCR\tesseract.exe",
    "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
    EnvGet("LOCALAPPDATA") "\Programs\Tesseract-OCR\tesseract.exe",
    EnvGet("LOCALAPPDATA") "\Tesseract-OCR\tesseract.exe"
]
Tesseract := TesseractPaths[1]
for p in TesseractPaths
    if FileExist(p)
    {
        Tesseract := p
        break
    }

; PURPLE TEXT FILTER
; Only pixels close to the rebirth tag colour are kept for OCR, everything
; else is blanked out, so other chat text / the purple game glow is ignored.
; Colour of "[R13]" in chat is RGB 255,120,230. Tolerance is per channel.
UsePurpleFilter := true
Purple_R   := 255
Purple_G   := 120
Purple_B   := 230
Purple_Tol := 45

; YELLOW ASCENSION TAG "[A1]" - RGB 255,200,30.
; The "[LV 215]" tag is almost the same yellow but Blue is 60 instead of 30,
; so Blue gets its own tighter tolerance to keep the level tag out.
Yellow_R    := 255
Yellow_G    := 200
Yellow_B    := 30
Yellow_Tol  := 45
Yellow_BTol := 15

; Rebirths needed to ascend FROM each ascension level:
; A0 -> 10, then 25 per level (A1 -> 25, A2 -> 50, A3 -> 75 ...)
RequiredRebirths(A) => (A = 0) ? 10 : 25 * A

OCR_Scale := 3            ; upscale before OCR - small chat text reads much better

; DAY / NIGHT + DAY NUMBER - read from the left panel ("Day 4" header and the
; "DAY" / "NIGHT - MILD ..." / "INTERMISSION" line). Read in the same scan as
; the chat. Region is X, Y, W, H and covers the line moving down when the
; kills bar shows.
DayNightRegion := [20, 365, 265, 150]

; ==========================================
; KEEP SHATTERED SUN EQUIPPED
; ==========================================
; Hotbar slots have a bevelled edge: normal slot = light top edge / dark
; bottom edge, equipped (darkened) slot = dark top edge / light bottom edge.
KeepEquipped     := true
EquipWeapon      := "Shattered Sun"  ; weapon to keep equipped (Settings > Equip / M1)
; Hotbar label patterns for each weapon (labels get cut short, e.g. "Shattered Sun...")
WeaponPatterns   := Map("Shattered Sun", "i)shatt|tered"
                      , "False Eclipse", "i)false|eclip|clipse")
EquipNameRegex   := WeaponPatterns[EquipWeapon]
EquipFindMs      := 20000        ; re-read the hotbar labels this often (slots move)
EquipCheckMs     := 2000         ; how often to check it's still equipped
HotbarLabelRegion := [566, 1050, 688, 18]  ; X, Y, W, H of the slot name labels
Slot1CenterX     := 604          ; centre of slot 1 (1920x1080)
SlotPitch        := 76           ; distance between slots
SlotTopEdgeY     := 1009         ; inner top edge of the slots
SlotBottomEdgeY  := 1069         ; inner bottom edge of the slots

; ==========================================
; KEEP THE COSMETICS (CASE) WINDOW OPEN
; ==========================================
; If it's closed while the macro is running: MENU (bottom left) -> Cosmetics.
KeepCosmeticsOpen := true
CosmeticsCheckMs  := 2000
MenuButtonXY      := [526, 1040]   ; MENU at the left of the hotbar
CosmeticsMenuXY   := [602, 839]    ; "Cosmetics" in the menu that pops up
CosmeticsCaseTabXY := [694, 356]   ; CASE tab inside the window
ResultsOkXY       := [960, 741]    ; green OK on the case results screen
ResultsOkColor    := 0x19572B      ; RGB 25,87,43
SkipAnimBoxXY     := [899, 681]    ; "Skip animation" checkbox (X in it = on)
SkipAnimTextRegion := [918, 672, 94, 18]  ; the "Skip animation" words - shows the case page is visible
; Points that only match while the window is open: [x, y, colour, tolerance]
CosmeticsOpenPts  := [[695, 348, 0x131A3C, 8]    ; selected CASE tab
                    , [634, 500, 0x262625, 4]    ; left border
                    , [634, 650, 0x262625, 4]
                    , [1287, 500, 0x262625, 4]]  ; right border

; ==========================================
; AUTO NEW GAME (low day restart)
; ==========================================
; If the day is RestartMaxDay or lower and it's NOT night, go to the main menu
; and start a new Dawn of the Armageddon game from a later day.
; Settings > Test runs it once by hand for testing.
AutoRestart       := true
RestartMaxDay     := 10
MainMenuXY        := [62, 79]
ChatButtonXY      := [138, 34]  ; chat bubble button - closes the chat window over MAIN MENU
ChatOpenMinPixels := 180        ; bright pixels on the icon that mean "chat open" (open ~300, closed ~60)
ServersXY         := [259, 485]
ServersColor      := 0x3565C9   ; blue SERVERS button  (RGB 53,101,201)
NewGameXY         := [580, 423]
NewGameColor      := 0x2F9E4F   ; green NEW GAME button (RGB 47,158,79)
DifficultyXY      := [1281, 455] ; rightmost card "DAWN OF THE ARMAGEDDON" (Choose Difficulty)
DifficultySelXY   := [1281, 538] ; where that card shows its "SELECTED" bar
                                 ; (Dawn's bar is dark red with WHITE text - ~300 white px
                                 ;  when selected, 0 when not)
ContinueXY        := [1260, 755] ; green CONTINUE
ContinueColor     := 0x2F9E4F
StartDayLeftXY    := [511, 615]  ; "<" under START DAY
StartDayBox       := [532, 600, 128, 32]  ; X, Y, W, H of the orange "DAY 1" text box
StartDayColor     := 0xFFB13B      ; orange text (RGB 255,177,59)
StartGameXY       := [609, 792]  ; green CREATE LOBBY button
StartGameColor    := 0x2F9E4F
; Back on the main menu: check the info box says "FRESH SERVER" + "DAY 50",
; then PLAY -> DEPLOY.
InfoBoxRegion     := [66, 305, 386, 47]  ; X, Y, W, H of the green-text box
InfoTextColor     := 0x7DFF5A            ; RGB 125,255,90
InfoDayDigitsX    := [112, 165]     ; x range of the day number after "DAY" in the info box
InfoDayDigitsY    := [330, 346]     ; y range of that line
MainMenuCheckMs   := 3000           ; how often to look for the main menu (PLAY) screen
PlayXY            := [259, 414]
PlayClicks        := 3           ; minimum PLAY clicks (new servers lag)
PlayClickGapMs    := 1500        ; time between PLAY clicks
PlayColor         := 0x2F9E4F
DeployXY          := [960, 927]
DeployColor       := 0x2F9E4F
RestartLoadMs     := 15000      ; wait after START GAME before carrying on
RestartCooldownMs := 90000      ; don't auto-retry sooner than this after an attempt
MenuStepMs        := 2000       ; wait between each menu click (the menus animate in)

; ==========================================
; SKILL TREE (runs automatically when ASCEND READY; Settings > Test runs it by hand)
; ==========================================
; Unfinished nodes have GREEN level text (1/5), maxed ones ORANGE (MAX).
; The routine opens the tree (SkillTreeKey), finds every green level box on screen,
; clicks the node, clicks the green Upgrade button until the box turns MAX
; (or stops changing = not enough points), then explores outward with WASD
; wherever level boxes reach the screen edge, until the whole tree is covered.

; MODE (Settings > General)
;   "Ascension" - clicks + R detection; at the ascension requirement it turns
;                 Auto RB off and maxes the skill tree.
;   "Rebirth"   - clicks + R detection only. Keeps Auto RB on, never touches
;                 the skill tree.
MacroMode        := "Ascension"

; Green "AUTO RB: ON" button (bottom middle). Any green in this area = ON.
AutoRBRegion     := [1302, 942, 1398, 964]
AutoRBClickXY    := [1350, 952]
AutoRBColor      := 0x19572B  ; RGB 25,87,43

SkillTreeKey     := "x"         ; key that opens / closes the skill tree
SkillPanelColor  := 0x6E1F18  ; red "Reset skills" button - used to tell the tree is open
SkillPanelRegion := [1610, 80, 1895, 104]
SkillCloseXY     := [1886, 32]           ; X on the Skills panel (fallback close)
SkillExclude     := [1600, 0, 1920, 140] ; ignore anything under the Skills panel

LevelTextColor   := 0x7DFF5A  ; green "1/5" text  (RGB 125,255,90)
MaxTextColor     := 0xFFB13B  ; orange "MAX" text (RGB 255,177,59) - used for exploring
LevelTextTol     := 45
UpgradeBtnColor  := 0x19572B  ; green Upgrade button (RGB 25,87,43)
UpgradeBtnTol    := 8

NodeClickOffsetY := 38        ; click this far ABOVE the level box (on the node name)
NodeEdgeMargin   := 60        ; ignore nodes this close to the screen edge (pan to them instead)
MaxUpgradesPerNode := 15
UpgradeWaitMs    := 700       ; stop spamming once the level hasn't changed for this long
OutOfPointsAfter := 3         ; this many nodes in a row with no progress = out of points
CheckUpgradeCost := false     ; true = read the Upgrade button and only buy if it costs "pt"
                              ; (off now that purple nodes are allowed - branch colours below decide)
UpgradeGapMs     := 70        ; pause between Upgrade clicks inside a burst
UpgradeBurstClicks := 5       ; clicks per burst before checking the screen again

; Branch colours that are NEVER bought. Checked on the popup's category band,
; so it also catches unbought (dark grey) nodes in that branch.
BlockedBranchColors := [0x417883]   ; light blue / teal branch (RGB 65,120,131)
BlockedBranchTol    := 12

; Purple (Ascension) branch - costs rebirths. For now it's always bought
; whenever the normal tree is being invested. See PurpleAllowed() to change that.
PurpleBranchColor   := 0x6E4083     ; RGB 110,64,131

; Panning / exploring
SkillAutoCalibrate := true    ; measure pan speed + direction on the first run
SkillPanTarget   := 0.6       ; each step moves this fraction of the screen (overlap keeps edges covered)
SkillPanMs       := 700       ; key hold per step if calibration can't measure it
SkillEdgeBand    := 220       ; boxes within this many px of an edge = tree continues that way
SkillMaxViews    := 30        ; safety cap on views visited per run
SkillMaxRadius   := 6         ; max steps away from the start in any direction
SkillSettleMs    := 400       ; wait after panning before scanning
SkillPassesPerView := 5       ; rescans per view (catches nodes hidden behind an open popup)

; Close the Cosmetics window first so it doesn't cover the tree
CloseCosmeticsFirst := true
CosmeticsCloseXY    := [1272, 321]

; ==========================================
; DISCORD WEBHOOK
; ==========================================
; Paste your webhook URL (Server Settings > Integrations > Webhooks > Copy URL).
; Leave it empty to turn notifications off. Settings > Test sends a test message.
WebhookURL     := ""
WebhookName    := "Unsungrinder"
WebhookMention := ""          ; e.g. "<@123456789012345678>" to be pinged on
                              ; ascend ready / errors. Leave empty for no ping.

; Which events get posted
WH_Start       := true        ; macro started / paused / closed
WH_Rebirth     := true        ; every new rebirth (R14 -> R15)
WH_Ascension   := true        ; ascension level changed
WH_AscendReady := true        ; rebirth requirement reached (pings)
WH_SkillTree   := true        ; skill tree started / finished
WH_Errors      := true        ; OCR keeps failing, skill tree errors (pings)
WH_DayNight    := false       ; post every day / night change
WH_Restart     := true        ; auto new game started / failed
WH_Equip       := false       ; post each time Shattered Sun had to be re-equipped
WH_Cosmetics   := false       ; post each time the Cosmetics window had to be reopened
OCRErrorAlertAfter := 10      ; consecutive OCR failures before an alert

; ==========================================
; SETTINGS FILE (auto-saved, export / import)
; ==========================================
; Everything below is saved in unsungrinder_settings.ini next to the script.
; Values in that file override the defaults above. Use the Settings button on
; the dashboard to change them, or to export / import / reset the file.

SettingsFile := A_ScriptDir "\unsungrinder_settings.ini"
; carry over settings / learned digits from before the rename
if (!FileExist(SettingsFile) && FileExist(A_ScriptDir "\roblox_macro_settings.ini"))
    FileMove(A_ScriptDir "\roblox_macro_settings.ini", SettingsFile)
if (!FileExist(A_ScriptDir "\unsungrinder_glyphs.txt") && FileExist(A_ScriptDir "\roblox_glyphs.txt"))
    FileMove(A_ScriptDir "\roblox_glyphs.txt", A_ScriptDir "\unsungrinder_glyphs.txt")

SettingsLayout := Map(
    "General",   ["MacroMode", "OpenModeIndex", "Point2", "Point3", "ClickDelay", "ChatMessage"
                 , "Chat_Interval", "OCR_Interval", "OCREngine", "UserChatTimeout"],
    "M1Lock",    ["UseM1Lock", "M1EscDelayMs", "M1RelockMs"],
    "Webhook",   ["WebhookURL", "WebhookName", "WebhookMention", "WH_Start", "WH_Rebirth"
                 , "WH_Ascension", "WH_AscendReady", "WH_SkillTree", "WH_Errors", "WH_DayNight"
                 , "WH_Restart", "WH_Equip", "WH_Cosmetics", "OCRErrorAlertAfter"],
    "SkillTree", ["SkillTreeKey", "CheckUpgradeCost", "UpgradeGapMs", "UpgradeBurstClicks"
                 , "MaxUpgradesPerNode", "OutOfPointsAfter", "BlockedBranchColors", "SkillAutoCalibrate"
                 , "SkillPanTarget", "SkillPanMs", "SkillMaxViews", "SkillMaxRadius"
                 , "SkillPassesPerView", "CloseCosmeticsFirst", "NodeClickOffsetY"],
    "NewGame",   ["AutoRestart", "RestartMaxDay", "MenuStepMs", "PlayClicks", "PlayClickGapMs"
                 , "RestartLoadMs", "RestartCooldownMs"],
    "Equip",     ["KeepEquipped", "EquipWeapon", "EquipFindMs", "EquipCheckMs"],
    "Cosmetics", ["KeepCosmeticsOpen", "CosmeticsCheckMs"],
    "Detection", ["OCR_X", "OCR_Y", "OCR_W", "OCR_H", "Purple_R", "Purple_G", "Purple_B", "Purple_Tol"
                 , "Yellow_R", "Yellow_G", "Yellow_B", "Yellow_Tol", "Yellow_BTol"
                 , "DayNightRegion", "HotbarLabelRegion"],
    "Positions", ["MainMenuXY", "ChatButtonXY", "ServersXY", "NewGameXY", "DifficultyXY"
                 , "DifficultySelXY", "ContinueXY", "StartDayLeftXY", "StartGameXY", "PlayXY"
                 , "DeployXY", "MenuButtonXY", "CosmeticsMenuXY", "CosmeticsCaseTabXY", "ResultsOkXY"
                 , "SkipAnimBoxXY", "CosmeticsCloseXY", "AutoRBClickXY", "SkillCloseXY"
                 , "Slot1CenterX", "SlotPitch", "SlotTopEdgeY", "SlotBottomEdgeY"
                 , "M1FallbackXY", "CosmeticsRect"]
)

; value -> text for the ini ("960,741" for positions, hex for colours)
SettingToText(Name, V)
{
    if IsObject(V)
    {
        T := ""
        for X in V
            T .= (T = "" ? "" : ",") (InStr(Name, "Color") ? Format("0x{:06X}", X) : X)
        return T
    }
    if (InStr(Name, "Color") && IsInteger(V))
        return Format("0x{:06X}", V)
    return V
}

; text from the ini -> value, shaped like the default
TextToSetting(Default, T)
{
    if IsObject(Default)
    {
        Out := []
        for Part in StrSplit(T, ",", " `t")
            if (Part != "")
                Out.Push(IsNumber(Part) ? Part + 0 : Part)
        return Out.Length ? Out : Default
    }
    if (IsNumber(Default) && IsNumber(T))
        return T + 0
    if IsNumber(Default)
        return Default                      ; garbage in a number setting - keep default
    return T
}

; Read the file (adds any settings it doesn't have yet, with their defaults)
LoadSettings()
{
    global
    local Section, Names, Name, T, Missing
    Missing := !FileExist(SettingsFile)
    for Section, Names in SettingsLayout
        for Name in Names
        {
            T := IniRead(SettingsFile, Section, Name, Chr(1))
            if (T = Chr(1))
                IniWrite(SettingToText(Name, %Name%), SettingsFile, Section, Name)
            else
                %Name% := TextToSetting(%Name%, T)
        }
}

; Save one setting right away (used by the hotkeys)
SaveSetting(Name)
{
    global
    local Section, Names, N
    for Section, Names in SettingsLayout
        for N in Names
            if (N = Name)
                IniWrite(SettingToText(Name, %Name%), SettingsFile, Section, Name)
}

; Save everything that's currently in memory
SaveAllSettings()
{
    global
    local Section, Names, Name
    for Section, Names in SettingsLayout
        for Name in Names
            IniWrite(SettingToText(Name, %Name%), SettingsFile, Section, Name)
}

LoadSettings()

; things worked out from the settings
if (WebhookName = "Roblox Macro")       ; old default name -> new one
    WebhookName := "Unsungrinder", SaveSetting("WebhookName")
OpenModeIndex := Max(1, Min(OpenModeIndex, OpenModes.Length))
if !WeaponPatterns.Has(EquipWeapon)
    EquipWeapon := "Shattered Sun"
EquipNameRegex := WeaponPatterns[EquipWeapon]
Point1 := [OpenModes[OpenModeIndex].X, OpenModes[OpenModeIndex].Y]

; ==========================================
; STATE
; ==========================================

Running := false
ChatBusy := false
M1Locked := false
M1LockTick := 0
OCRBusy := false
OCRPid := 0
OCRStart := 0
WH_Pending := []          ; in-flight webhook requests (kept alive until sent)
LastPostedR := ""
LastPostedA := ""
PendingR := ""            ; a new R must be read twice in a row before posting
OCRFailStreak := 0
OCRAlertSent := false
DayPhase := "Unknown"     ; "Day" / "Night"
PhaseSince := 0
DayCount := 0
NightCount := 0
PhaseLog := []            ; recent changes, newest last ("03:15 Night")
DayNum := "Unknown"       ; current day number (from the "Day 4" header)
DayNumPending := ""       ; a new day number must be read twice in a row
RestartBusy := false
LastRestartTick := -999999
WasAscendReady := false
ClickHolds := Map()       ; active reasons the click loop is paused (see HoldClicks)
ClickIndex := 1
CurrentRebirth := "Unknown"
CurrentAscension := "Unknown"
AscendReady := false        ; true once R >= required R for the current A
ReadyStreak := 0            ; scans in a row that said "ready"
CandR := "", CandRCount := 0
CandA := "", CandACount := 0
NoATagCount := 0
CurrentTask := "Paused"
SkillBusy := false
SkillAbort := false
SkillsDoneForA := -1        ; ascension level the tree was last completed for
SkillStatus := "Idle"
PanKeys := Map("R", "d", "L", "a", "D", "s", "U", "w")
PanMsX := SkillPanMs
PanMsY := SkillPanMs
PanCalibrated := false
OCRStatus := "Waiting"
ChatStatus := "Waiting"

TempImage := A_Temp "\roblox_ocr.png"
OCRBase   := A_Temp "\roblox_ocr"          ; OCR writes roblox_ocr.txt
PSFile    := A_Temp "\roblox_capture.ps1"
CSFile    := A_Temp "\roblox_ocrhelper.cs"
GlyphFile := A_ScriptDir "\unsungrinder_glyphs.txt"   ; digit shapes for reading [A#][R#] (learns over time)
GlyphBase := A_Temp "\roblox_glyph"             ; tag reader output (roblox_glyph.txt)
OcrLibFile := A_Temp "\roblox_ocrlib.ps1"
SkillPSFile  := A_Temp "\roblox_skillscan.ps1"
SkillOutFile := A_Temp "\roblox_skillscan.txt"
BtnPSFile    := A_Temp "\roblox_btnocr.ps1"
BtnImage     := A_Temp "\roblox_btn.png"
BtnBase      := A_Temp "\roblox_btn"
DNImage      := A_Temp "\roblox_daynight.png"
DNBase       := A_Temp "\roblox_daynight"
TextPSFile   := A_Temp "\roblox_textocr.ps1"
TextImage    := A_Temp "\roblox_text.png"
TextBase     := A_Temp "\roblox_text"
HotbarPSFile := A_Temp "\roblox_hotbar.ps1"
HotbarImage  := A_Temp "\roblox_hotbar.png"
HotbarBase   := A_Temp "\roblox_hotbar"

CoordMode "Pixel", "Screen"

WriteHelperScripts()

; ==========================================
; DASHBOARD
; ==========================================

Dashboard := Gui("+AlwaysOnTop", "Unsungrinder v" AppVersion)
Dashboard.BackColor := "202431"
Dashboard.SetFont("s10 cFFFFFF", "Segoe UI")

Dashboard.AddText("x15 y10 w220 cAAAAAA", "CURRENT TASK")
TaskLabel := Dashboard.AddText("x15 y28 w220 Center", "Paused")

Dashboard.AddText("x15 y58 w220 cAAAAAA", "ASCENSION / REBIRTH")
Dashboard.SetFont("s20")
AscLabel     := Dashboard.AddText("x15  y74 w105 h36 Right cFFC81E", "A?")
RebirthLabel := Dashboard.AddText("x130 y74 w105 h36 Left  cFF78E6", "R?")
Dashboard.SetFont("s10")
AscReqLabel  := Dashboard.AddText("x15 y112 w220 Center cAAAAAA", "Next ascend: ?")

Dashboard.AddText("x15 y136 w220 cAAAAAA", "CURRENT CLICK")
ClickLabel := Dashboard.AddText("x15 y154 w220 Center", "Point 1")

Dashboard.AddText("x15 y190 w220 Center cAAAAAA", "F1  Start / Pause")
Dashboard.AddText("x15 y210 w220 Center cAAAAAA", "F8  Exit")
StatusBtn   := Dashboard.AddButton("x15 y238 w105 h28", "Status")
SettingsBtn := Dashboard.AddButton("x130 y238 w105 h28", "Settings")
StatusBtn.OnEvent("Click", (*) => ShowStatusWindow())
SettingsBtn.OnEvent("Click", (*) => ShowSettingsWindow())
Dashboard.SetFont("s8")
Dashboard.AddText("x5 y274 w240 Center c6A7090", "v" AppVersion "  -  by @equinoxi_q (Discord)")
Dashboard.SetFont("s10")

Dashboard.OnEvent("Close", (*) => ExitApp())

Dashboard.Show("x" (A_ScreenWidth - 265) " y150 w250 h296 NoActivate")

; ---------- STATUS WINDOW ----------
StatusGui := Gui("+AlwaysOnTop +Owner" Dashboard.Hwnd, "Unsungrinder - Status")
StatusGui.BackColor := "202431"
StatusGui.SetFont("s10 cFFFFFF", "Segoe UI")

StatusGui.AddText("x15 y10 w270 cAAAAAA", "STATUS")
StStatus := StatusGui.AddText("x15 y28 w270 Center cFF7777", "PAUSED")

StatusGui.AddText("x15 y58 w270 cAAAAAA", "SKILL TREE")
SkillLabel := StatusGui.AddText("x15 y76 w270 Center c7DFF5A", "Idle")

EquipCaption := StatusGui.AddText("x15 y106 w270 cAAAAAA", "WEAPON (slot ?)")
EquipLabel := StatusGui.AddText("x15 y124 w270 Center cFFFFFF", "Unknown")

StatusGui.AddText("x15 y154 w270 cAAAAAA", "OCR MONITOR")
OCRLabel := StatusGui.AddText("x15 y172 w270 Center cFFCC66", "Waiting")

StatusGui.AddText("x15 y202 w270 cAAAAAA", "CHAT MESSAGE")
ChatLabel := StatusGui.AddText("x15 y220 w270 Center", "Waiting")

StatusGui.AddText("x15 y250 w270 cAAAAAA", "DAY / NIGHT")
PhaseLabel := StatusGui.AddText("x15 y268 w270 Center cFFFFFF", "Unknown")
PhaseLogLabel := StatusGui.AddText("x15 y286 w270 Center c888888", "Days 0  -  Nights 0")

StatusGui.AddText("x15 y316 w270 cAAAAAA", "SESSION")
StSession := StatusGui.AddText("x15 y334 w270 h80 cDDDDDD", "-")

StatusGui.Show("Hide w300 h425")

ShowStatusWindow()
{
    global StatusGui, Dashboard
    Dashboard.GetPos(&DX, &DY)
    StatusGui.Show("x" (DX - 310) " y" DY " NoActivate")
    UpdateDashboard()
}

; ==========================================
; DASHBOARD UPDATE
; ==========================================

UpdateDashboard()
{
    global Running, CurrentRebirth, CurrentTask
    global OCRStatus, ChatStatus, ClickIndex
    global TaskLabel, RebirthLabel
    global CurrentAscension, AscLabel, AscReqLabel, AscendReady
    global ClickLabel, OCRLabel, ChatLabel, M1Locked
    global SkillLabel, SkillStatus, MacroMode, SkillBusy
    global StStatus


    TaskLabel.Text := CurrentTask
    AscLabel.Text     := (CurrentAscension = "Unknown") ? "A?" : "A" CurrentAscension
    RebirthLabel.Text := (CurrentRebirth   = "Unknown") ? "R?" : "R" CurrentRebirth

    if (CurrentAscension = "Unknown")
        AscReqLabel.Text := "Next ascend: ?"
    else if AscendReady
        AscReqLabel.Text := "ASCEND READY (R" RequiredRebirths(CurrentAscension) ")"
    else
        AscReqLabel.Text := "Next ascend: R" RequiredRebirths(CurrentAscension)
    AscReqLabel.SetFont(AscendReady ? "c55DD88" : "cAAAAAA")
    ClickLabel.Text := "Point " ClickIndex (M1Locked ? "   -   M1 held" : "")
    OCRLabel.Text := OCRStatus
    ChatLabel.Text := ChatStatus
    SkillLabel.Text := (MacroMode = "Rebirth" && !SkillBusy) ? "Off (Rebirth mode)" : SkillStatus

    StStatus.Text := (Running ? "RUNNING" : "PAUSED") "  -  " StrUpper(MacroMode) " MODE"
    StStatus.SetFont(Running ? "c55DD88" : "cFF7777")
    UpdatePhaseLabel()
    UpdateSessionLabel()
}

; ==========================================
; CYCLE OPEN MODE ($5M -> $25M -> $50M)
; ==========================================

SetOpenMode(Index)
{
    global OpenModes, OpenModeIndex, Point1

    OpenModeIndex := Max(1, Min(Index, OpenModes.Length))
    Point1 := [OpenModes[OpenModeIndex].X, OpenModes[OpenModeIndex].Y]
    SaveSetting("OpenModeIndex")

    UpdateDashboard()
}

; ==========================================
; START / PAUSE
; ==========================================

F1::
{
    global Running, CurrentTask, SkillBusy, SkillAbort
    global ClickDelay, OCR_Interval, Chat_Interval, WH_Start, MacroMode

    Running := !Running

    if Running
    {
        global SessionStartTick
        SessionStartTick := A_TickCount
        CurrentTask := "Progression"

        SetTimer(Progression, ClickDelay)
        SetTimer(ReadRebirth, OCR_Interval)
        SetTimer(SendChat, Chat_Interval)

        ; Send a chat message right away so the R# tag is visible, then scan.
        ; Clicks are held until that first message is done, so a click can't
        ; land on the UI and steal focus from the chat box first.
        HoldClicks("startup")
        SetTimer(StartupChat, -1)

        if (MacroMode = "Rebirth")
            SetTimer(() => EnsureAutoRBOn(), -2500)    ; after the startup chat

        if WH_Start
            Notify("Macro started (" MacroMode " mode)", RebirthSummary(), 0x55DD88)
    }
    else
    {
        if SkillBusy
            SkillAbort := true          ; pausing also stops the skill routine

        CurrentTask := "Paused"

        SetTimer(Progression, 0)
        SetTimer(ReadRebirth, 0)
        SetTimer(SendChat, 0)
        SetTimer(() => ReleaseM1(), -1)     ; let go of the held M1

        if WH_Start
            Notify("Macro paused", RebirthSummary(), 0xFF7777)
    }

    UpdateDashboard()
}

; ==========================================
; CLICK HOLDS
; ==========================================
; Anything that needs the click loop to stop calls HoldClicks("reason") and
; ReleaseClicks("reason") when done. Clicks only run while no holds are active,
; so multiple things can pause clicking at once without fighting each other.
; OCR does NOT hold clicks - it runs in the background.

HoldClicks(Reason)
{
    global ClickHolds
    ClickHolds[Reason] := true
}

ReleaseClicks(Reason)
{
    global ClickHolds
    if ClickHolds.Has(Reason)
        ClickHolds.Delete(Reason)
}

; ==========================================
; PROGRESSION
; ==========================================

Progression()
{
    global Point1, Point2, Point3
    global ClickIndex, Running, ClickHolds, M1Locked

    if (!Running || ClickHolds.Count)
        return

    Points := [Point1, Point2, Point3]
    Pt := Points[ClickIndex]

    ; Point3 is a world click - it would cancel the locked M1, so skip it
    if (ClickIndex = 3 && M1Locked)
        Pt := [0, 0]

    if (Pt[1] != 0 || Pt[2] != 0)
        Click Pt[1], Pt[2]

    ClickIndex := Mod(ClickIndex, 3) + 1

    UpdateDashboard()
}

; ==========================================
; CHAT MESSAGE (macro sends it)
; ==========================================

StartupChat()
{
    global Running, ChatBusy

    KeyWait("F1")                   ; F1 still held down can swallow the "/"
    Sleep(150)

    if Running
    {
        ; If a scheduled message happens to be mid-send, wait for it
        while ChatBusy
            Sleep(50)
        SendChat()
        SetTimer(() => ReadRebirth(), -1000)   ; scan once the tag is in chat

        ; lock M1 on, then make sure "Skip animation" is ticked before the case clicks start
        FocusRoblox()
        LockM1()
        EnsureSkipAnimation()
    }

    ReleaseClicks("startup")
}

SendChat(Force := false)
{
    global Running, ChatMessage, ChatStatus, ChatBusy, CurrentTask, RobloxExe
    global SkillBusy, RestartBusy

    ; Never type while the skill tree / new game routine is running
    if ((!Running && !Force) || ChatBusy || SkillBusy || RestartBusy)
        return

    ChatBusy := true
    HoldClicks("chat")
    CurrentTask := "Sending chat"
    ChatStatus := "Sending..."
    UpdateDashboard()

    KeyWait("F4")                   ; don't type while the hotkey is held

    ; Make sure Roblox has focus, otherwise "/" goes nowhere
    if WinExist(RobloxExe) && !WinActive(RobloxExe)
    {
        WinActivate(RobloxExe)
        WinWaitActive(RobloxExe, , 1)
    }

    Sleep(200)              ; let any in-progress click finish
    Send("/")
    Sleep(300)
    SendText(ChatMessage)
    Sleep(100)
    Send("{Enter}")
    Sleep(200)

    ChatStatus := "Sent at " FormatTime(, "HH:mm:ss")
    CurrentTask := Running ? "Progression" : "Paused"
    ReleaseClicks("chat")
    ChatBusy := false
    UpdateDashboard()
}

; Force one chat message now (works while paused too).
; Runs on a fresh thread so a hotkey press can't stall the click timer.
ForceChat() => SetTimer(() => SendChat(true), -1)

; ==========================================
; YOU TYPING IN CHAT
; ==========================================
; Pressing / in Roblox pauses clicks until you press Enter or Esc
; (or after UserChatTimeout ms, in case you click away instead).
; The macro's own "/" doesn't trigger this - AHK ignores its own sent keys.

#HotIf WinActive(RobloxExe)
$~/::
{
    global CurrentTask, Running, UserChatTimeout
    HoldClicks("user chat")
    CurrentTask := "You're typing"
    UpdateDashboard()
    SetTimer(EndUserChat, -UserChatTimeout)
}
$~Enter::
$~Esc::
{
    EndUserChat()
}
#HotIf

EndUserChat()
{
    global ClickHolds, CurrentTask, Running
    if !ClickHolds.Has("user chat")
        return
    ReleaseClicks("user chat")
    SetTimer(EndUserChat, 0)
    if !ClickHolds.Count
        CurrentTask := Running ? "Progression" : "Paused"
    UpdateDashboard()
}

; ==========================================
; OCR REBIRTH DETECTION (non-blocking)
; ==========================================
; Starts one hidden PowerShell process that captures the chat, filters it and
; runs OCR. AHK doesn't wait for it - CheckOCR polls until it's done,
; so the click loop keeps running the whole time.

ReadRebirth()
{
    global Running, OCRBusy, OCRPid, OCRStart
    global OCR_X, OCR_Y, OCR_W, OCR_H, OCR_Scale
    global Tesseract, OCREngine, TempImage, OCRBase, PSFile, CSFile
    global UsePurpleFilter, Purple_R, Purple_G, Purple_B, Purple_Tol
    global Yellow_R, Yellow_G, Yellow_B, Yellow_Tol, Yellow_BTol
    global DayNightRegion, DNImage, DNBase, GlyphFile, GlyphBase
    global OCRStatus, SkillBusy, RestartBusy

    ; The tree / menus cover the chat, so don't scan while they're open
    if (!Running || OCRBusy || SkillBusy || RestartBusy)
        return

    try
    {
        if (OCREngine = "tesseract" && !FileExist(Tesseract))
            throw Error("Tesseract not found")

        if FileExist(TempImage)
            FileDelete(TempImage)
        if FileExist(OCRBase ".txt")
            FileDelete(OCRBase ".txt")
        if FileExist(OCRBase "_raw.txt")
            FileDelete(OCRBase "_raw.txt")
        if FileExist(OCRBase "_line.txt")
            FileDelete(OCRBase "_line.txt")
        if FileExist(GlyphBase ".txt")
            FileDelete(GlyphBase ".txt")

        PSCmd := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' PSFile '"'
            . ' -X ' OCR_X ' -Y ' OCR_Y ' -W ' OCR_W ' -H ' OCR_H
            . ' -Out "' TempImage '" -Cs "' CSFile '"'
            . ' -Scale ' OCR_Scale ' -Filter ' (UsePurpleFilter ? 1 : 0)
            . ' -PR ' Purple_R ' -PG ' Purple_G ' -PB ' Purple_B ' -Tol ' Purple_Tol
            . ' -YR ' Yellow_R ' -YG ' Yellow_G ' -YB ' Yellow_B ' -YTol ' Yellow_Tol ' -YBTol ' Yellow_BTol
            . ' -Tess "' OcrTessArg() '" -OutBase "' OCRBase '"'
            . ' -DX ' DayNightRegion[1] ' -DY ' DayNightRegion[2]
            . ' -DW ' DayNightRegion[3] ' -DH ' DayNightRegion[4]
            . ' -DOut "' DNImage '" -DOutBase "' DNBase '"'
            . ' -Glyphs "' GlyphFile '" -GlyphOut "' GlyphBase '.txt"'

        if FileExist(DNBase ".txt")
            FileDelete(DNBase ".txt")

        Run(PSCmd, , "Hide", &Pid)

        OCRPid := Pid
        OCRStart := A_TickCount
        OCRBusy := true
        OCRStatus := "Scanning..."
        SetTimer(CheckOCR, 100)
    }
    catch as Err
    {
        OCRStatus := "Error: " Err.Message
    }

    UpdateDashboard()
}

CheckOCR()
{
    global OCRBusy, OCRPid, OCRStart
    global TempImage, OCRBase
    global CurrentRebirth, CurrentAscension, AscendReady, OCRStatus, GlyphBase
    global MacroMode, Running, SkillBusy, SkillsDoneForA, ReadyStreak
    global OCRFailStreak, OCRAlertSent

    ; Still running?
    if ProcessExist(OCRPid)
    {
        if (A_TickCount - OCRStart > 15000)
        {
            ProcessClose(OCRPid)
            SetTimer(CheckOCR, 0)
            OCRBusy := false
            OCRStatus := "Error: OCR timed out"
            UpdateDashboard()
        }
        return
    }

    SetTimer(CheckOCR, 0)

    ReadDayNight()

    try
    {
        if !FileExist(TempImage)
            throw Error("Screenshot capture failed")
        if !FileExist(OCRBase ".txt")
            throw Error("OCR produced no output")

        Output := FileRead(OCRBase ".txt")
        if (SubStr(Output, 1, 7) = "!!NOOCR")
            throw Error("Windows OCR unavailable - add English in Windows language settings")
        ; Read both the colour-filtered tags and the plain chat text, and prefer
        ; whichever read has BOTH the A and the R from the same line.
        RawText := ""       ; (plain-chat reading removed - only the purple / yellow tags count)
        LineText := FileExist(OCRBase "_line.txt") ? FileRead(OCRBase "_line.txt") : ""
        if (SubStr(LineText, 1, 7) = "!!NOOCR")
            LineText := ""
        lR := "", lA := "", mR := "", mA := "", rR := "", rA := ""
        ParseTags(LineText, &lR, &lA)
        ParseTags(Output, &mR, &mA)
        ParseTags(RawText, &rR, &rA)
        ; Best: the pixel-exact tag reader (no OCR). Unknown digits ("?") are
        ; learned when the value can only be one thing (R counts up by 1).
        gR := "", gA := ""
        ReadGlyphResult(&gR, &gA)
        if (gR != "")
            FoundR := gR, FoundA := (gA != "") ? gA : (lR != "" && IsNumber(lA)) ? lA : ""
        else if (lR != "" && IsNumber(lA))      ; newest line, cropped - OCR
            FoundR := lR, FoundA := lA
        else if (rR != "" && IsNumber(rA))
            FoundR := rR, FoundA := rA
        else if (mR != "" && IsNumber(mA))
            FoundR := mR, FoundA := mA
        else
        {
            FoundR := (lR != "") ? lR : (rR != "") ? rR : mR
            ; "no A tag" only counts if neither read saw one
            FoundA := (rA = "none" && (mA = "none" || mA = "")) || (mA = "none" && rA = "") ? "none" : ""
        }

        if (FoundR != "")
        {
            ; A value / R value only change after the same reading twice in a row
            AcceptReading(FoundR, FoundA)

            if (CurrentAscension != "Unknown" && CurrentRebirth != "Unknown")
                AscendReady := CurrentRebirth >= RequiredRebirths(CurrentAscension)
            ReadyStreak := AscendReady ? ReadyStreak + 1 : 0

            OCRStatus := "Detected " ((CurrentAscension = "Unknown") ? "" : "A" CurrentAscension " ") "R" CurrentRebirth
            OCRFailStreak := 0
            OCRAlertSent := false
            WebhookProgressEvents()

            ; Ascension requirement reached -> max the skill tree (once per A level).
            ; Needs a confirmed A and 3 "ready" scans in a row.
            if (AscendReady && ReadyStreak >= 3 && MacroMode = "Ascension" && Running && !SkillBusy
                && SkillsDoneForA != CurrentAscension)
                SetTimer(() => RunSkillTree(), -1)
        }
        else
        {
            ; show a bit of what was read, to help tune things
            Seen := Trim(RegExReplace(LineText " | " Output " | " RawText, "\s+", " "))
            OCRStatus := "No R detected" (Seen != "|" ? " (read: " SubStr(Seen, 1, 28) ")" : "")
            OCRFailed("no R tag found in chat")
        }
    }
    catch as Err
    {
        OCRStatus := "Error: " Err.Message
        OCRFailed(Err.Message)
    }

    OCRBusy := false
    UpdateDashboard()
}

; ==========================================
; M1 LOCK
; ==========================================

SetTimer(CheckM1Relock, 5000)

; hold M1 on Point3 -> ESC -> let go -> wait -> ESC
; Only runs if M1 isn't already locked (and never twice at the same time),
; so the ESC menu is only opened once per lock.
LockM1(Force := false)
{
    global UseM1Lock, Point3, M1EscDelayMs, M1Locked, M1LockTick, CurrentTask, ClickHolds
    if !UseM1Lock
        return
    if ((M1Locked && !Force) || ClickHolds.Has("m1lock"))
        return
    HoldClicks("m1lock")
    Prev := CurrentTask
    CurrentTask := "Locking M1"
    UpdateDashboard()

    FocusRoblox()
    ; the weapon MUST be in hand first - locking M1 with nothing equipped gets you killed
    CurrentTask := "Equipping weapon"
    UpdateDashboard()
    EnsureWeaponEquipped()
    CurrentTask := "Locking M1"
    UpdateDashboard()

    ; Get the mouse onto open ground (Point3) and make sure the GAME has seen it
    ; there - an instant jump can leave Roblox thinking it's still over the case
    ; UI, and holding M1 on a UI button instead of the world gets you killed.
    if !MoveMouseToGround()
    {
        CurrentTask := Prev
        ReleaseClicks("m1lock")
        UpdateDashboard()
        return                          ; couldn't get clear of the UI - try again later
    }
    G := M1GroundPoint()
    Click(G[1], G[2], "Down")
    Sleep(300)
    Send("{Esc}")                     ; Roblox menu opens while M1 is down
    Sleep(400)
    Click("Up")
    Sleep(M1EscDelayMs)
    Send("{Esc}")                     ; close the menu - M1 stays held
    Sleep(400)

    M1Locked := true
    M1LockTick := A_TickCount
    CurrentTask := Prev
    ReleaseClicks("m1lock")
    UpdateDashboard()
}

; Where to hold M1: Point3, unless that's inside the Cosmetics window area,
; then a fallback spot to the right of it.
M1GroundPoint()
{
    global Point3, CosmeticsRect, M1FallbackXY
    R := CosmeticsRect
    if (Point3[1] >= R[1] && Point3[1] <= R[3] && Point3[2] >= R[2] && Point3[2] <= R[4])
        return M1FallbackXY
    return Point3
}

; Glide the mouse to the ground point, nudge it so Roblox registers the move,
; then confirm it's really there and not over the case window.
MoveMouseToGround()
{
    global CosmeticsRect
    G := M1GroundPoint()
    Loop 3
    {
        MouseMove(G[1], G[2], 4)            ; glide (not an instant jump)
        Sleep(80)
        MouseMove(G[1] + 3, G[2] + 3, 0)    ; small wiggle - forces a hover update
        Sleep(60)
        MouseMove(G[1], G[2], 0)
        Sleep(250)                           ; let the game catch up
        MouseGetPos(&MX, &MY)
        R := CosmeticsRect
        OverCase := (MX >= R[1] && MX <= R[3] && MY >= R[2] && MY <= R[4])
        if (Abs(MX - G[1]) <= 2 && Abs(MY - G[2]) <= 2 && !OverCase)
            return true
    }
    return false
}

; one world click lets go of the held M1
ReleaseM1()
{
    global M1Locked, Point3, ChatBusy, SkillBusy, RestartBusy
    if !M1Locked
        return
    while (ChatBusy || SkillBusy || RestartBusy)
        Sleep(100)
    FocusRoblox()
    Click(Point3[1], Point3[2])
    M1Locked := false
    UpdateDashboard()
}

; safety net: redo the lock every M1RelockMs while things are quiet
CheckM1Relock()
{
    global UseM1Lock, M1RelockMs, M1LockTick, Running, SkillBusy, RestartBusy, ChatBusy, ClickHolds
    if (!UseM1Lock || !M1RelockMs || !Running || SkillBusy || RestartBusy || ChatBusy || ClickHolds.Count)
        return
    if (A_TickCount - M1LockTick < M1RelockMs)
        return
    if !HotbarVisible()                 ; only in game
        return
    LockM1(true)
}

; ==========================================
; KEEP THE COSMETICS (CASE) WINDOW OPEN
; ==========================================

CosmeticsMissCount := 0
CosmeticsReopens := 0
SetTimer(CheckCosmetics, CosmeticsCheckMs)

CosmeticsOpen()
{
    global CosmeticsOpenPts
    Hits := 0
    for P in CosmeticsOpenPts
        if ColorNear(PixelGetColor(P[1], P[2]), P[3], P[4])
            Hits++
    return Hits >= CosmeticsOpenPts.Length - 1      ; allow one point to be covered
}

; Close the Cosmetics window with its X (only if it's open). True when closed.
CloseCosmetics()
{
    global CosmeticsCloseXY
    Loop 3
    {
        if !CosmeticsOpen()
            return true
        Click(CosmeticsCloseXY[1], CosmeticsCloseXY[2])
        Sleep(800)
    }
    return !CosmeticsOpen()
}

; Make sure "Skip animation" is ticked on the case page. Clears a results
; screen first (OK) so the checkbox is visible. True if it ends up ticked.
EnsureSkipAnimation()
{
    global ResultsOkXY, ResultsOkColor, SkipAnimBoxXY, SkipAnimTextRegion

    if !CosmeticsOpen()
        return false

    ; results screen covering the page? press OK
    if PixelSearch(&fx, &fy, ResultsOkXY[1] - 60, ResultsOkXY[2] - 12, ResultsOkXY[1] + 60, ResultsOkXY[2] + 12, ResultsOkColor, 8)
    {
        Click(ResultsOkXY[1], ResultsOkXY[2])
        Sleep(800)
    }

    T := SkipAnimTextRegion
    if (CountBrightPixels(T[1], T[2], T[3], T[4], 200) < 60)
        return false                        ; case page not showing

    Loop 2
    {
        if SkipAnimTicked()
            return true
        Click(SkipAnimBoxXY[1], SkipAnimBoxXY[2])
        Sleep(600)
    }
    return SkipAnimTicked()
}

SkipAnimTicked()
{
    global SkipAnimBoxXY
    ; the white X inside the box is ~26 bright pixels; empty box ~0
    return CountBrightPixels(SkipAnimBoxXY[1] - 10, SkipAnimBoxXY[2] - 10, 21, 21, 200) >= 12
}

CheckCosmetics()
{
    global KeepCosmeticsOpen, Running, SkillBusy, RestartBusy, ChatBusy, ClickHolds
    global CosmeticsMissCount, CosmeticsReopens, CurrentTask, WH_Cosmetics
    global MenuButtonXY, CosmeticsMenuXY, CosmeticsCaseTabXY

    if (!KeepCosmeticsOpen || !Running || SkillBusy || RestartBusy)
        return

    if CosmeticsOpen()
    {
        CosmeticsMissCount := 0
        return
    }

    ; only in game (hotbar showing), closed twice in a row, nothing else going on
    if !HotbarVisible()
        return
    if (++CosmeticsMissCount < 2)
        return
    if (ChatBusy || ClickHolds.Has("user chat") || ClickHolds.Has("equip"))
        return
    CosmeticsMissCount := 0

    HoldClicks("cosmetics")
    CurrentTask := "Reopening Cosmetics"
    UpdateDashboard()

    FocusRoblox()
    Sleep(150)
    LockM1()                            ; M1 held before the case UI opens
    Click(MenuButtonXY[1], MenuButtonXY[2])
    Sleep(1000)
    Click(CosmeticsMenuXY[1], CosmeticsMenuXY[2])

    Opened := false
    Start := A_TickCount
    while (A_TickCount - Start < 3000)
    {
        Sleep(150)
        if CosmeticsOpen()
        {
            Opened := true
            break
        }
    }

    if Opened
    {
        Click(CosmeticsCaseTabXY[1], CosmeticsCaseTabXY[2])   ; make sure it's on CASE
        Sleep(400)
        EnsureSkipAnimation()
        CosmeticsReopens++
        if WH_Cosmetics
            Notify("Reopened Cosmetics", "The case window was closed.", 0xB8A2FF)
    }
    else if !CosmeticsOpen()
    {
        ; menu may still be open - close it with the MENU button again
        Click(MenuButtonXY[1], MenuButtonXY[2])
        Sleep(400)
    }

    ReleaseClicks("cosmetics")
    CurrentTask := Running ? "Progression" : "Paused"
    UpdateDashboard()
}

; ==========================================
; KEEP SHATTERED SUN EQUIPPED
; ==========================================

EquipState := "Unknown"     ; "Equipped" / "Unequipped" / "Unknown" (hotbar not visible)
EquipSlot := 0              ; found by reading the hotbar labels (0 = not found yet)
EquipFoundTick := -999999
EquipMissCount := 0         ; consecutive "unequipped" readings
EquipFixes := 0

SetTimer(CheckEquipped, EquipCheckMs)

; "Equipped" / "Unequipped" / "Unknown" for a hotbar slot
SlotState(N)
{
    global Slot1CenterX, SlotPitch, SlotTopEdgeY, SlotBottomEdgeY
    CX := Slot1CenterX + (N - 1) * SlotPitch
    DarkTop := 0, LightTop := 0, DarkBot := 0, LightBot := 0
    for DX in [-22, -8, 8, 22]
    {
        T := Integer(PixelGetColor(CX + DX, SlotTopEdgeY)) & 0xFF
        B := Integer(PixelGetColor(CX + DX, SlotBottomEdgeY)) & 0xFF
        if (T <= 25)
            DarkTop++
        else if (T >= 40 && T <= 55)
            LightTop++
        if (B <= 25)
            DarkBot++
        else if (B >= 40 && B <= 55)
            LightBot++
    }
    ; must actually be a hotbar slot: plain slot grey (38,38,37) inside, both sides
    for DX in [-32, 32]
        if !ColorNear(PixelGetColor(CX + DX, (SlotTopEdgeY + SlotBottomEdgeY) // 2), 0x262625, 4)
            return "Unknown"

    if (DarkTop >= 3 && LightBot >= 3)
        return "Equipped"
    if (LightTop >= 3 && DarkBot >= 3)
        return "Unequipped"
    return "Unknown"            ; hotbar hidden / covered (menu, skill tree...)
}

CheckEquipped()
{
    global KeepEquipped, EquipSlot, EquipState, EquipMissCount, EquipFixes
    global Running, SkillBusy, RestartBusy, ChatBusy, ClickHolds, WH_Equip, EquipLabel
    global Slot1CenterX, SlotPitch, SlotTopEdgeY, SlotBottomEdgeY
    global EquipFoundTick, EquipFindMs, EquipCaption, EquipWeapon, M1Locked

    if (!KeepEquipped)
        return

    ; ---- find which slot Shattered Sun is in (slots can move) ----
    if (Running && !SkillBusy && !RestartBusy
        && (EquipSlot = 0 || A_TickCount - EquipFoundTick > EquipFindMs)
        && HotbarVisible())
        LocateEquipSlot()

    if (EquipSlot = 0)
    {
        EquipLabel.Text := HotbarVisible() ? "Not found in hotbar" : "Hotbar not visible"
        EquipLabel.SetFont("c888888")
        return
    }

    EquipState := SlotState(EquipSlot)

    if (EquipState = "Equipped")
        EquipLabel.Text := "Equipped" (EquipFixes ? "  (re-equipped " EquipFixes "x)" : "")
    else if (EquipState = "Unequipped")
        EquipLabel.Text := "NOT EQUIPPED"
    else
        EquipLabel.Text := "Hotbar not visible"
    EquipLabel.SetFont(EquipState = "Equipped" ? "c55DD88" : EquipState = "Unequipped" ? "cFF7777" : "c888888")

    if (EquipState != "Unequipped")
    {
        EquipMissCount := 0
        return
    }

    ; must read "unequipped" twice in a row, and only when nothing else is going on
    if (++EquipMissCount < 2)
        return
    if (!Running || SkillBusy || RestartBusy || ChatBusy || ClickHolds.Has("user chat") || ClickHolds.Has("cosmetics"))
        return
    EquipMissCount := 0

    HoldClicks("equip")
    Done := EnsureWeaponEquipped()
    ReleaseClicks("equip")

    if Done
    {
        ; swapping weapons drops the held M1 - lock it again now the weapon is in hand
        M1Locked := false
        LockM1()
        EquipFixes++
        EquipLabel.Text := "Equipped  (re-equipped " EquipFixes "x)"
        EquipLabel.SetFont("c55DD88")
        if WH_Equip
            Notify("Re-equipped " EquipWeapon, "Slot " EquipSlot " was unequipped.", 0xFFC81E)
    }
}

; Make sure the chosen weapon is in hand. Re-reads the hotbar labels first so
; the right slot is used. Returns true if it had to equip it (and it worked),
; false if it was already equipped or couldn't be done.
EnsureWeaponEquipped()
{
    global KeepEquipped, EquipSlot, Slot1CenterX, SlotPitch, SlotTopEdgeY, SlotBottomEdgeY
    if !KeepEquipped || !HotbarVisible()
        return false
    if !LocateEquipSlot()
        return false
    if (SlotState(EquipSlot) != "Unequipped")
        return false                    ; already equipped
    FocusRoblox()
    Sleep(100)
    Send(EquipSlot "")                  ; number key equips that slot
    Loop 10                             ; wait up to 1s
    {
        Sleep(100)
        if (SlotState(EquipSlot) = "Equipped")
            return true
    }
    ; key didn't take - click the slot instead
    Click(Slot1CenterX + (EquipSlot - 1) * SlotPitch, (SlotTopEdgeY + SlotBottomEdgeY) // 2)
    Loop 10
    {
        Sleep(100)
        if (SlotState(EquipSlot) = "Equipped")
            return true
    }
    return false
}

HotbarVisible()
{
    return (SlotState(1) != "Unknown" || SlotState(5) != "Unknown" || SlotState(9) != "Unknown")
}

; Reads the hotbar labels and sets EquipSlot to the slot whose label matches
; EquipNameRegex. Returns the slot, or 0 if it isn't in the hotbar.
LocateEquipSlot()
{
    global EquipSlot, EquipFoundTick, EquipCaption, EquipNameRegex
    global HotbarLabelRegion, Slot1CenterX, SlotPitch
    global HotbarPSFile, HotbarImage, HotbarBase, CSFile, Tesseract

    EquipFoundTick := A_TickCount
    R := HotbarLabelRegion

    if FileExist(HotbarBase ".words")
        FileDelete(HotbarBase ".words")
    Cmd := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' HotbarPSFile '"'
        . ' -X ' R[1] ' -Y ' R[2] ' -W ' R[3] ' -H ' R[4]
        . ' -Out "' HotbarImage '" -Cs "' CSFile '"'
        . ' -Tess "' OcrTessArg() '" -OutBase "' HotbarBase '"'
    RunWait(Cmd, , "Hide")
    if !FileExist(HotbarBase ".words")
        return EquipSlot := 0

    Found := 0
    ; each line: left <tab> width <tab> word   (pixels in the 3x image)
    Loop Parse FileRead(HotbarBase ".words"), "`n", "`r"
    {
        F := StrSplit(A_LoopField, "`t")
        if (F.Length < 3 || !RegExMatch(F[3], EquipNameRegex))
            continue
        ; word centre (image is 3x scaled) -> screen x -> slot number
        X := R[1] + (F[1] + F[2] / 2) / 3
        Found := Floor((X - (Slot1CenterX - SlotPitch / 2)) / SlotPitch) + 1
        break
    }

    if (Found >= 1 && Found <= 9)
        EquipSlot := Found
    else
        EquipSlot := 0
    global EquipWeapon
    EquipCaption.Text := "WEAPON: " StrUpper(EquipWeapon) " (slot " (EquipSlot ? EquipSlot : "?") ")"
    return EquipSlot
}

; ==========================================
; DAY / NIGHT
; ==========================================

; Called after each chat scan - reads the text OCR found in the left
; panel: the "Day 4" header and the "DAY" / "NIGHT - ..." / "INTERMISSION" line
ReadDayNight()
{
    global DNBase, DayPhase, PhaseSince, DayCount, NightCount, PhaseLog, WH_DayNight
    global DayNum, DayNumPending

    if !FileExist(DNBase ".txt")
        return
    Txt := FileRead(DNBase ".txt")

    ; ---- day number ("Day 4") - must read the same twice in a row ----
    if RegExMatch(Txt, "Day\s*(\d{1,4})", &M)
    {
        N := M[1] + 0
        if (N = DayNum)
            DayNumPending := ""
        else if (N = DayNumPending)
        {
            DayNum := N
            DayNumPending := ""
        }
        else
            DayNumPending := N
    }

    ; ---- phase ----
    New := ""
    if RegExMatch(Txt, "NIGHT|NIGH|IGHT")
        New := "Night"
    else if RegExMatch(Txt, "INTERMIS|TERMISSION")
        New := "Intermission"
    else if RegExMatch(Txt, "\bDAY\b")
        New := "Day"

    if (New != "" && New != DayPhase)
    {
        Old := DayPhase
        Lasted := PhaseSince ? A_TickCount - PhaseSince : 0
        DayPhase := New
        PhaseSince := A_TickCount

        if (Old != "Unknown")               ; don't count the first reading
        {
            if (New = "Day")
                DayCount++
            else if (New = "Night")
                NightCount++
            PhaseLog.Push(FormatTime(, "HH:mm") " " New)
            if (PhaseLog.Length > 20)
                PhaseLog.RemoveAt(1)

            if WH_DayNight
                Notify(New " started"
                    , Old " lasted " FormatDuration(Lasted) "`n" RebirthSummary()
                    , New = "Night" ? 0x5A5AFF : 0xFFE08A)
        }
    }

    CheckAutoRestart()
    UpdateDashboard()
}

; Low day and not night -> start a new game from a later day
CheckAutoRestart()
{
    global AutoRestart, RestartMaxDay, DayNum, DayPhase, Running, RestartBusy, SkillBusy
    global LastRestartTick, RestartCooldownMs
    if (AutoRestart && Running && !RestartBusy && !SkillBusy
        && A_TickCount - LastRestartTick > RestartCooldownMs
        && DayNum != "Unknown" && DayNum <= RestartMaxDay
        && (DayPhase = "Day" || DayPhase = "Intermission"))
        SetTimer(() => RunNewGame(), -1)
}

; Session info for the status window
SessionStartTick := 0
SessionStartR := ""
SessionStartA := ""
NewGameCount := 0

UpdateSessionLabel()
{
    global StSession, Running, SessionStartTick, SessionStartR, SessionStartA
    global CurrentRebirth, CurrentAscension, EquipFixes, CosmeticsReopens, NewGameCount, M1Locked
    if (SessionStartR = "" && CurrentRebirth != "Unknown")
        SessionStartR := CurrentRebirth, SessionStartA := CurrentAscension
    Gained := (SessionStartR != "" && CurrentRebirth != "Unknown" && CurrentAscension = SessionStartA)
        ? CurrentRebirth - SessionStartR : "?"
    Up := (Running && SessionStartTick) ? FormatDuration(A_TickCount - SessionStartTick) : "paused"
    StSession.Text := "Running for:  " Up
        . "`nRebirths this session:  " Gained
        . "`nRe-equips: " EquipFixes "    Cosmetics reopens: " CosmeticsReopens
        . "`nNew games: " NewGameCount "    M1: " (M1Locked ? "held" : "not held")
}

UpdatePhaseLabel()
{
    global PhaseLabel, PhaseLogLabel, DayPhase, PhaseSince, DayCount, NightCount, PhaseLog, DayNum

    if (DayPhase = "Unknown")
        PhaseLabel.Text := "Unknown"
    else
        PhaseLabel.Text := ((DayNum = "Unknown") ? "" : "Day " DayNum "  -  ")
            . StrUpper(DayPhase) "  for " FormatDuration(A_TickCount - PhaseSince)
    PhaseLabel.SetFont(DayPhase = "Night" ? "c8C8CFF" : DayPhase = "Day" ? "cFFE08A" : "cFFFFFF")

    Last := PhaseLog.Length ? "  -  last " PhaseLog[PhaseLog.Length] : ""
    PhaseLogLabel.Text := "Days " DayCount "  -  Nights " NightCount Last
}

FormatDuration(Ms)
{
    S := Ms // 1000
    return (S >= 60) ? (S // 60) "m " Format("{:02}", Mod(S, 60)) "s" : S "s"
}

; keep the "for Xm Ys" counter ticking
SetTimer(() => (UpdatePhaseLabel(), UpdateSessionLabel()), 1000)

; ==========================================
; MAIN MENU -> PLAY (days over RestartMaxDay only)
; ==========================================

MenuSeenCount := 0
SetTimer(CheckMainMenu, MainMenuCheckMs)

AtMainMenu()
{
    global PlayXY, PlayColor, ServersXY, ServersColor
    return WaitForColor(PlayXY, PlayColor, 0) && WaitForColor(ServersXY, ServersColor, 0)
}

; Sitting on the main menu (new server, disconnect, kicked...)?
;   day over RestartMaxDay -> PLAY + DEPLOY
;   day RestartMaxDay or lower -> start a new game instead
CheckMainMenu()
{
    global Running, RestartBusy, SkillBusy, MenuSeenCount, RestartMaxDay, CurrentTask, RestartLoadMs, M1Locked
    global AutoRestart, LastRestartTick, RestartCooldownMs, WH_Restart, WH_Errors

    if (!Running || RestartBusy || SkillBusy)
        return
    if !AtMainMenu()
    {
        MenuSeenCount := 0
        return
    }
    if (++MenuSeenCount < 2)            ; seen twice in a row
        return
    MenuSeenCount := 0

    D := MenuServerDay()
    if (D = "")
        return                          ; couldn't read the day - try again next time

    if (D > RestartMaxDay)
    {
        RestartBusy := true
        M1Locked := false
        HoldClicks("restart")
        try
        {
            PlayAndDeploy()
            Sleep(RestartLoadMs)
            LockM1()
            if WH_Restart
                Notify("Rejoined from the main menu", "Day " D " - pressed PLAY and DEPLOY", 0x55DD88)
        }
        catch as Err
        {
            if WH_Errors
                Notify("Play from main menu failed", Err.Message, 0xFF5555, true)
        }
        ReleaseClicks("restart")
        RestartBusy := false
        CurrentTask := Running ? "Progression" : "Paused"
        UpdateDashboard()
    }
    else if (AutoRestart && A_TickCount - LastRestartTick > RestartCooldownMs)
        SetTimer(() => RunNewGame(), -1)    ; low day - make a fresh Day 50 server
}

; Day number shown in the main-menu info box, or "" if unreadable.
; Uses OCR, and checks it against how wide the number is (1 digit vs 2+),
; because the pixel font fools OCR (50 can read as 30).
MenuServerDay()
{
    Digits := InfoDayDigitCount()
    if (Digits = 0)
        return ""

    Info := ReadInfoBox()
    Num := ""
    if RegExMatch(Info, "i)DAY\s*([0-9OoIl|]{1,4})", &M)
        Num := StrReplace(StrReplace(StrReplace(StrReplace(StrReplace(M[1], "O", "0"), "o", "0"), "I", "1"), "l", "1"), "|", "1") + 0

    ; trust OCR only when it has the same number of digits as the width says
    if (Num != "" && StrLen(Num "") = Digits)
        return Num
    ; otherwise go by the width alone: 1 digit = day 1-9, 2+ digits = 10+
    ; (reported as 99 so it counts as "over 10"; exact value unknown)
    return (Digits = 1) ? 1 : 99
}

; How many digits the day number in the info box has, from its pixel width
; ("DAY 4" ~7 px, "DAY 50" ~19 px). 0 = box not visible.
InfoDayDigitCount()
{
    global InfoDayDigitsX, InfoDayDigitsY, InfoTextColor
    H := InfoDayDigitsY[2] - InfoDayDigitsY[1]
    First := 0, Last := 0, Gap := 0
    X := InfoDayDigitsX[1]
    while (X <= InfoDayDigitsX[2])
    {
        if (CountColorPixels(X, InfoDayDigitsY[1], 1, H, InfoTextColor, 60) > 0)
        {
            if !First
                First := X
            Last := X
            Gap := 0
        }
        else if First
        {
            if (++Gap > 5)                  ; gap after the number = end of it
                break
        }
        X++
    }
    if !First
        return 0
    W := Last - First + 1
    return (W < 13) ? 1 : (W < 26) ? 2 : 3
}

; Click PLAY (at least PlayClicks times - fresh servers lag), then DEPLOY
PlayAndDeploy()
{
    global PlayXY, PlayColor, DeployXY, DeployColor, PlayClicks, PlayClickGapMs, MenuStepMs, CurrentTask
    CurrentTask := "Main menu: play"
    UpdateDashboard()
    FocusRoblox()
    Clicked := 0
    Start := A_TickCount
    Loop
    {
        DeployUp := WaitForColor(DeployXY, DeployColor, 100)
        if (Clicked >= PlayClicks && DeployUp)
            break
        if (A_TickCount - Start > 25000)
            throw Error("DEPLOY button didn't appear")
        if (Clicked < PlayClicks || WaitForColor(PlayXY, PlayColor, 100))
        {
            Click(PlayXY[1], PlayXY[2])
            Clicked++
        }
        Sleep(PlayClickGapMs)
    }
    Sleep(MenuStepMs)
    Click(DeployXY[1], DeployXY[2])
    Sleep(MenuStepMs)
}

; ==========================================
; AUTO NEW GAME
; ==========================================

TestNewGame() => SetTimer(() => RunNewGame(true), -1)

RunNewGame(Manual := false)
{
    global RestartBusy, SkillBusy, ChatBusy, CurrentTask, Running, WH_Restart, WH_Errors
    global MainMenuXY, ServersXY, ServersColor, NewGameXY, NewGameColor
    global DifficultyXY, DifficultySelXY, ContinueXY, ContinueColor
    global StartDayLeftXY
    global StartGameXY, StartGameColor, RestartLoadMs
    global PlayXY, PlayColor, RestartMaxDay
    global DayNum, DayNumPending, DayPhase, PhaseSince, LastRestartTick, MenuStepMs, M1Locked, NewGameCount

    if (RestartBusy || SkillBusy)
        return

    RestartBusy := true
    M1Locked := false                   ; leaving the game drops it
    LastRestartTick := A_TickCount
    HoldClicks("restart")
    while ChatBusy
        Sleep(50)

    FromDay := DayNum
    CurrentTask := "New game..."
    UpdateDashboard()
    if WH_Restart
        Notify("Starting a new game", (Manual ? "Started manually (Settings > Test)" : "Day " FromDay " during the " DayPhase " - restarting from a later day") "`n" RebirthSummary(), 0x3565C9)

    try
    {
        KeyWait("F9")
        FocusRoblox()

        ; 1. Main menu (close the chat window first - it covers the button)
        CurrentTask := "New game: main menu"
        UpdateDashboard()
        if !AtMainMenu()                ; already there (e.g. after a disconnect)? skip
        {
            if !CloseCosmetics()
                throw Error("Couldn't close the Cosmetics window")
            Sleep(MenuStepMs)
            if !CloseChatWindow()
                throw Error("Couldn't close the chat window")
            Sleep(MenuStepMs)
            Click(MainMenuXY[1], MainMenuXY[2])
            if !WaitForColor(ServersXY, ServersColor, 8000)
                throw Error("Main menu didn't open (is it night?)")
            Sleep(MenuStepMs)
        }

        ; 2. Servers
        CurrentTask := "New game: servers"
        UpdateDashboard()
        Click(ServersXY[1], ServersXY[2])
        if !WaitForColor(NewGameXY, NewGameColor, 5000)
            throw Error("Servers window didn't open")
        Sleep(MenuStepMs)

        ; 3. New Game -> Choose Difficulty window
        CurrentTask := "New game: difficulty"
        UpdateDashboard()
        Click(NewGameXY[1], NewGameXY[2])
        if !WaitForColor(ContinueXY, ContinueColor, 8000)
            throw Error("Choose Difficulty didn't open")
        Sleep(MenuStepMs)

        ; 4. Rightmost card (Dawn of the Armageddon) - check it says SELECTED
        Loop 3
        {
            Click(DifficultyXY[1], DifficultyXY[2])
            Sleep(MenuStepMs)
            if DifficultySelected()
                break
            if (A_Index = 3)
                throw Error("Couldn't select Dawn of the Armageddon")
        }

        ; 5. Continue -> lobby setup
        Click(ContinueXY[1], ContinueXY[2])
        if !WaitForColor(StartGameXY, StartGameColor, 8000)
            throw Error("Lobby setup didn't open")
        Sleep(MenuStepMs)

        ; 6. Start day: left arrow (Day 50)
        CurrentTask := "New game: start day"
        UpdateDashboard()
        ; click "<", then keep clicking while the box still shows "DAY 1"
        ; (the lobby can lag and miss a click)
        Loop 8
        {
            Click(StartDayLeftXY[1], StartDayLeftXY[2])
            Sleep(MenuStepMs)
            if !StartDayIsDay1()
                break
            if (A_Index = 8)
                throw Error("Start day stayed on DAY 1")
        }

        ; 7. Create lobby -> back to the main menu
        CurrentTask := "New game: create lobby"
        UpdateDashboard()
        Click(StartGameXY[1], StartGameXY[2])
        if !WaitForColor(PlayXY, PlayColor, 10000)
            throw Error("Didn't get back to the main menu")
        Sleep(MenuStepMs)

        ; 8. The server must be past day 10 before we play
        CurrentTask := "New game: checking day"
        UpdateDashboard()
        D := ""
        Loop 6
        {
            D := MenuServerDay()
            if (D > RestartMaxDay)
                break
            Sleep(1000)
        }
        if !(D > RestartMaxDay)
            throw Error("Server day isn't over " RestartMaxDay " (read: " D ")")

        ; 9. Play -> Deploy
        PlayAndDeploy()

        CurrentTask := "New game: loading"
        UpdateDashboard()
        Sleep(RestartLoadMs)
        LockM1()

        NewGameCount++
        if WH_Restart
            Notify("New game started", "Fresh server - Dawn of the Armageddon - Day 50 - deployed", 0x55DD88)
    }
    catch as Err
    {
        if WH_Errors
            Notify("New game failed", Err.Message, 0xFF5555, true)
        CurrentTask := "New game failed: " Err.Message
        UpdateDashboard()
        Sleep(2000)
    }

    ; day info is from the old game - read it fresh
    DayNum := "Unknown"
    DayNumPending := ""
    DayPhase := "Unknown"
    PhaseSince := 0

    ReleaseClicks("restart")
    RestartBusy := false
    CurrentTask := Running ? "Progression" : "Paused"
    UpdateDashboard()
}

; Chat window open = the chat bubble icon (top left) is FILLED white.
; Closed = only a white outline. Counts bright pixels around the icon:
; open is ~300, closed ~60.
ChatWindowOpen()
{
    global ChatButtonXY, ChatOpenMinPixels
    return CountBrightPixels(ChatButtonXY[1] - 12, ChatButtonXY[2] - 12, 24, 24, 230) >= ChatOpenMinPixels
}

; Number of pixels in the area whose R, G and B are all >= MinV
CountBrightPixels(X, Y, W, H, MinV)
{
    hdcScreen := DllCall("GetDC", "Ptr", 0, "Ptr")
    hdcMem := DllCall("CreateCompatibleDC", "Ptr", hdcScreen, "Ptr")

    bi := Buffer(40, 0)
    NumPut("UInt", 40, bi, 0)
    NumPut("Int", W, bi, 4)
    NumPut("Int", -H, bi, 8)
    NumPut("UShort", 1, bi, 12)
    NumPut("UShort", 32, bi, 14)

    pBits := 0
    hbm := DllCall("CreateDIBSection", "Ptr", hdcMem, "Ptr", bi, "UInt", 0
        , "Ptr*", &pBits, "Ptr", 0, "UInt", 0, "Ptr")
    old := DllCall("SelectObject", "Ptr", hdcMem, "Ptr", hbm, "Ptr")
    DllCall("BitBlt", "Ptr", hdcMem, "Int", 0, "Int", 0, "Int", W, "Int", H
        , "Ptr", hdcScreen, "Int", X, "Int", Y, "UInt", 0x00CC0020)

    Count := 0
    Loop W * H
    {
        C := NumGet(pBits, (A_Index - 1) * 4, "UInt")
        if ((C & 0xFF) >= MinV && ((C >> 8) & 0xFF) >= MinV && ((C >> 16) & 0xFF) >= MinV)
            Count++
    }

    DllCall("SelectObject", "Ptr", hdcMem, "Ptr", old)
    DllCall("DeleteObject", "Ptr", hbm)
    DllCall("DeleteDC", "Ptr", hdcMem)
    DllCall("ReleaseDC", "Ptr", 0, "Ptr", hdcScreen)
    return Count
}

; Click the chat bubble button until the chat window is closed
CloseChatWindow()
{
    global ChatButtonXY
    Loop 3
    {
        if !ChatWindowOpen()
            return true
        Click(ChatButtonXY[1], ChatButtonXY[2])
        Sleep(1000)
    }
    return !ChatWindowOpen()
}

; OCR the main-menu info box (green pixel text, e.g. "FRESH SERVER DAWN / DAY 50")
ReadInfoBox()
{
    global InfoBoxRegion, InfoTextColor, TextPSFile, TextImage, TextBase, CSFile, Tesseract
    R := InfoBoxRegion, C := InfoTextColor
    if FileExist(TextBase ".txt")
        FileDelete(TextBase ".txt")
    Cmd := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' TextPSFile '"'
        . ' -X ' R[1] ' -Y ' R[2] ' -W ' R[3] ' -H ' R[4]
        . ' -CR ' ((C >> 16) & 0xFF) ' -CG ' ((C >> 8) & 0xFF) ' -CB ' (C & 0xFF) ' -Tol 60'
        . ' -Out "' TextImage '" -Cs "' CSFile '"'
        . ' -Tess "' OcrTessArg() '" -OutBase "' TextBase '"'
    RunWait(Cmd, , "Hide")
    return FileExist(TextBase ".txt") ? FileRead(TextBase ".txt") : ""
}

; Start-day box still says "DAY 1"? Single digit = little orange text
; ("DAY 1" ~87 px, "DAY 50" ~184 px).
StartDayIsDay1()
{
    global StartDayBox, StartDayColor
    B := StartDayBox
    N := CountColorPixels(B[1], B[2], B[3], B[4], StartDayColor, 60)
    return (N >= 30 && N < 135)
}

; Number of pixels in the area within Tol (per channel) of Color
CountColorPixels(X, Y, W, H, Color, Tol)
{
    TR := (Color >> 16) & 0xFF, TG := (Color >> 8) & 0xFF, TB := Color & 0xFF
    hdcScreen := DllCall("GetDC", "Ptr", 0, "Ptr")
    hdcMem := DllCall("CreateCompatibleDC", "Ptr", hdcScreen, "Ptr")
    bi := Buffer(40, 0)
    NumPut("UInt", 40, bi, 0), NumPut("Int", W, bi, 4), NumPut("Int", -H, bi, 8)
    NumPut("UShort", 1, bi, 12), NumPut("UShort", 32, bi, 14)
    pBits := 0
    hbm := DllCall("CreateDIBSection", "Ptr", hdcMem, "Ptr", bi, "UInt", 0
        , "Ptr*", &pBits, "Ptr", 0, "UInt", 0, "Ptr")
    old := DllCall("SelectObject", "Ptr", hdcMem, "Ptr", hbm, "Ptr")
    DllCall("BitBlt", "Ptr", hdcMem, "Int", 0, "Int", 0, "Int", W, "Int", H
        , "Ptr", hdcScreen, "Int", X, "Int", Y, "UInt", 0x00CC0020)
    Count := 0
    Loop W * H
    {
        C := NumGet(pBits, (A_Index - 1) * 4, "UInt")
        if (Abs(((C >> 16) & 0xFF) - TR) <= Tol && Abs(((C >> 8) & 0xFF) - TG) <= Tol && Abs((C & 0xFF) - TB) <= Tol)
            Count++
    }
    DllCall("SelectObject", "Ptr", hdcMem, "Ptr", old)
    DllCall("DeleteObject", "Ptr", hbm)
    DllCall("DeleteDC", "Ptr", hdcMem)
    DllCall("ReleaseDC", "Ptr", 0, "Ptr", hdcScreen)
    return Count
}

; White "SELECTED" text on the Dawn card's bar
DifficultySelected()
{
    global DifficultySelXY
    Start := A_TickCount
    while (A_TickCount - Start < 1500)
    {
        if (CountBrightPixels(DifficultySelXY[1] - 46, DifficultySelXY[2] - 8, 92, 17, 230) >= 100)
            return true
        Sleep(100)
    }
    return false
}

; Wait until the colour shows up around a point (e.g. a button appearing)
WaitForColor(XY, Color, TimeoutMs)
{
    Start := A_TickCount
    Loop                                ; always checks at least once
    {
        if PixelSearch(&fx, &fy, XY[1] - 30, XY[2] - 8, XY[1] + 30, XY[2] + 8, Color, 14)
            return true
        if (A_TickCount - Start >= TimeoutMs)
            return false
        Sleep(100)
    }
}


; ==========================================
; SKILL TREE ROUTINE
; ==========================================

ToggleSkillTree()
{
    global SkillBusy, SkillAbort
    if SkillBusy
        SkillAbort := true                      ; stop the running routine
    else
        SetTimer(() => RunSkillTree(true), -1)  ; run now, even if not ascend-ready
}

RunSkillTree(Manual := false)
{
    global SkillBusy, SkillAbort, SkillStatus, SkillsDoneForA, CurrentAscension
    global CurrentTask, Running, ChatBusy
    global CloseCosmeticsFirst, CosmeticsCloseXY
    global SkillSettleMs, SkillPassesPerView, OutOfPointsAfter
    global SkillMaxViews, SkillMaxRadius, SkillAutoCalibrate, PanCalibrated
    global WH_SkillTree, WH_Errors

    if SkillBusy
        return

    SkillBusy := true
    SkillAbort := false
    HoldClicks("skills")

    while ChatBusy                      ; let a chat message finish first
        Sleep(50)

    CurrentTask := "Skill tree"
    SkillStatus := "Opening tree..."
    UpdateDashboard()

    if WH_SkillTree
        Notify("Skill tree started", (Manual ? "Started manually (Settings > Test)" : "Ascension requirement reached") "`n" RebirthSummary(), 0x7DFF5A)

    Upgraded := 0
    Skipped := 0
    Pos := {X: 0, Y: 0}
    TreeOpened := false

    try
    {
        KeyWait("F3")
        FocusRoblox()

        ; Before ascending: stop the game rebirthing on its own
        if !Manual
        {
            SkillStatus := "Turning Auto RB off..."
            UpdateDashboard()
            if !SetAutoRB(false)
                throw Error("Couldn't turn Auto RB off")
        }

        if CloseCosmeticsFirst
        {
            CloseCosmetics()
            Sleep(300)
        }

        LockM1()                        ; M1 held before the tree opens
        Sleep(800)                      ; let the ESC menu finish closing first
        FocusRoblox()
        if !OpenSkillTree()
            throw Error("Tree didn't open")
        TreeOpened := true

        if (SkillAutoCalibrate && !PanCalibrated)
        {
            SkillStatus := "Calibrating pan..."
            UpdateDashboard()
            CalibratePan()
        }

        ; Explore outward from the starting view. A neighbouring view is only
        ; queued when level boxes (green OR orange) sit near that screen edge,
        ; i.e. the tree carries on in that direction.
        Visited := Map("0,0", true)
        Queue := [[0, 0]]
        ViewsDone := 0
        NoProgress := 0
        OutOfPoints := false
        Dirs := Map("L", [-1, 0], "R", [1, 0], "U", [0, -1], "D", [0, 1])

        while (Queue.Length && ViewsDone < SkillMaxViews)
        {
            CheckSkillAbort(Manual)

            ; go to the queued view closest to where we are now
            Best := 1, BestD := 99999
            for k, Q in Queue
            {
                D := Abs(Q[1] - Pos.X) + Abs(Q[2] - Pos.Y)
                if (D < BestD)
                    Best := k, BestD := D
            }
            V := Queue.RemoveAt(Best)

            PanTo(Pos, V[1], V[2])
            Sleep(SkillSettleMs)
            ViewsDone++

            LastScan := ""
            Loop SkillPassesPerView
            {
                SkillStatus := "View " ViewsDone " (" V[1] "," V[2] ") - scanning"
                UpdateDashboard()

                Scan := ScanSkillTree()
                LastScan := Scan
                if !Scan.Green.Length
                    break

                Progress := false
                for j, N in Scan.Green
                {
                    CheckSkillAbort(Manual)
                    SkillStatus := "View " ViewsDone " - node " j "/" Scan.Green.Length " (+" Upgraded ")"
                    UpdateDashboard()

                    Gained := UpgradeNode(N[1], N[2])

                    if (Gained > 0)
                    {
                        Upgraded += Gained
                        Progress := true
                        NoProgress := 0
                    }
                    else if (Gained = 0)        ; button there but nothing changed
                    {
                        NoProgress++
                        if (NoProgress >= OutOfPointsAfter)
                        {
                            OutOfPoints := true
                            break
                        }
                    }
                    else if (Gained <= -2)      ; blocked branch / not a skill-point cost
                        Skipped++
                }

                if (OutOfPoints || !Progress)
                    break
            }

            if OutOfPoints
                break

            ; queue neighbours the tree extends into
            if IsObject(LastScan)
            {
                for Dir, Off in Dirs
                {
                    if !LastScan.Edges[Dir]
                        continue
                    NX := V[1] + Off[1], NY := V[2] + Off[2]
                    Key := NX "," NY
                    if (Abs(NX) <= SkillMaxRadius && Abs(NY) <= SkillMaxRadius && !Visited.Has(Key))
                    {
                        Visited[Key] := true
                        Queue.Push([NX, NY])
                    }
                }
            }
        }

        PanTo(Pos, 0, 0)
        CloseSkillTree()
        TreeOpened := false

        SkillsDoneForA := CurrentAscension
        SkillStatus := (OutOfPoints ? "Out of points" : "Done") " (+" Upgraded ", " ViewsDone " views"
            . (Skipped ? ", " Skipped " skipped" : "") ")"

        if WH_SkillTree
            Notify("Skill tree finished", SkillStatus, 0x7DFF5A)
    }
    catch as Err
    {
        SkillStatus := (Err.Message = "Stopped") ? "Stopped (+" Upgraded ")" : "Error: " Err.Message

        if (Err.Message = "Stopped")
        {
            if WH_SkillTree
                Notify("Skill tree stopped", SkillStatus, 0xFFCC66)
        }
        else if WH_Errors
            Notify("Skill tree error", SkillStatus, 0xFF5555, true)
        if TreeOpened
        {
            try PanTo(Pos, 0, 0)
            try CloseSkillTree()
        }
    }

    ReleaseClicks("skills")
    SkillBusy := false
    CurrentTask := Running ? "Progression" : "Paused"
    UpdateDashboard()
}

CheckSkillAbort(Manual)
{
    global SkillAbort, Running
    if (SkillAbort || (!Manual && !Running))
        throw Error("Stopped")
}

FocusRoblox()
{
    global RobloxExe
    if WinExist(RobloxExe) && !WinActive(RobloxExe)
    {
        WinActivate(RobloxExe)
        WinWaitActive(RobloxExe, , 1)
    }
}

; ---------- open / close ----------

SkillTreeOpen()
{
    global SkillPanelColor, SkillPanelRegion
    R := SkillPanelRegion
    return PixelSearch(&fx, &fy, R[1], R[2], R[3], R[4], SkillPanelColor, 12)
}

OpenSkillTree()
{
    global SkillTreeKey
    if SkillTreeOpen()
        return true
    Loop 2
    {
        Send(SkillTreeKey)
        Loop 15                             ; wait up to 1.5s
        {
            Sleep(100)
            if SkillTreeOpen()
            {
                Sleep(300)                  ; let it finish animating in
                return true
            }
        }
    }
    return false
}

CloseSkillTree()
{
    global SkillTreeKey, SkillCloseXY
    if !SkillTreeOpen()
        return
    Send(SkillTreeKey)
    Sleep(500)
    if SkillTreeOpen()
    {
        Click(SkillCloseXY[1], SkillCloseXY[2])
        Sleep(400)
    }
}

; ---------- panning ----------

; Pos is in "view" units. PanKeys maps a direction to the key that reveals
; more of the tree that way (swapped automatically by CalibratePan if needed).
PanTo(Pos, TX, TY)
{
    global PanKeys, PanMsX, PanMsY
    while (Pos.X < TX)
    {
        PanStep(PanKeys["R"], PanMsX)
        Pos.X++
    }
    while (Pos.X > TX)
    {
        PanStep(PanKeys["L"], PanMsX)
        Pos.X--
    }
    while (Pos.Y < TY)
    {
        PanStep(PanKeys["D"], PanMsY)
        Pos.Y++
    }
    while (Pos.Y > TY)
    {
        PanStep(PanKeys["U"], PanMsY)
        Pos.Y--
    }
}

PanStep(Key, Ms)
{
    Send("{" Key " down}")
    Sleep(Ms)
    Send("{" Key " up}")
    Sleep(150)
}

; Press D once and measure how far (and which way) the level boxes moved.
; Sets the key direction and how long to hold keys so one step moves
; SkillPanTarget of the screen.
CalibratePan()
{
    global PanKeys, PanMsX, PanMsY, PanCalibrated, SkillPanMs, SkillPanTarget, SkillSettleMs

    Before := ScanSkillTree().All
    if (Before.Length < 4)
        return

    PanStep("d", SkillPanMs)
    Sleep(SkillSettleMs)
    After := ScanSkillTree().All
    PanStep("a", SkillPanMs)            ; go back
    Sleep(SkillSettleMs)

    Shift := VoteShift(Before, After)
    if !IsObject(Shift) || Abs(Shift[1]) < 40
        return                          ; couldn't tell - keep defaults

    ; Holding D should slide the tree LEFT (revealing more on the right).
    ; If it slid right, the keys are the other way round.
    if (Shift[1] > 0)
        PanKeys := Map("R", "a", "L", "d", "D", "w", "U", "s")
    else
        PanKeys := Map("R", "d", "L", "a", "D", "s", "U", "w")

    Speed := Abs(Shift[1]) / SkillPanMs          ; px per ms
    PanMsX := Round(Min(Max(SkillPanTarget * A_ScreenWidth  / Speed, 150), 4000))
    PanMsY := Round(Min(Max(SkillPanTarget * A_ScreenHeight / Speed, 150), 4000))
    PanCalibrated := true
}

; Most common offset between two sets of box positions (8px buckets)
VoteShift(A, B)
{
    Counts := Map()
    BestKey := "", BestN := 0
    for P in A
        for Q in B
        {
            Key := Round((Q[1] - P[1]) / 8) "," Round((Q[2] - P[2]) / 8)
            N := Counts.Has(Key) ? Counts[Key] + 1 : 1
            Counts[Key] := N
            if (N > BestN)
                BestN := N, BestKey := Key
        }
    if (BestN < 4)
        return ""
    Parts := StrSplit(BestKey, ",")
    return [Parts[1] * 8, Parts[2] * 8]
}

; ---------- node detection ----------

; Screenshot the screen and find every level box.
; Returns {Green: [[x,y]...] safe to click, All: [[x,y]...], Edges: Map(L/R/U/D -> bool)}
ScanSkillTree()
{
    global SkillPSFile, SkillOutFile, CSFile
    global LevelTextColor, MaxTextColor, LevelTextTol, SkillExclude
    global NodeEdgeMargin, SkillEdgeBand

    if FileExist(SkillOutFile)
        FileDelete(SkillOutFile)

    G := LevelTextColor, M := MaxTextColor, E := SkillExclude
    Cmd := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' SkillPSFile '"'
        . ' -W ' A_ScreenWidth ' -H ' A_ScreenHeight
        . ' -Out "' SkillOutFile '" -Cs "' CSFile '"'
        . ' -GR ' ((G >> 16) & 0xFF) ' -GG ' ((G >> 8) & 0xFF) ' -GB ' (G & 0xFF)
        . ' -MR ' ((M >> 16) & 0xFF) ' -MG ' ((M >> 8) & 0xFF) ' -MB ' (M & 0xFF)
        . ' -Tol ' LevelTextTol
        . ' -EX1 ' E[1] ' -EY1 ' E[2] ' -EX2 ' E[3] ' -EY2 ' E[4]

    RunWait(Cmd, , "Hide")

    if !FileExist(SkillOutFile)
        throw Error("Skill scan failed")

    W := A_ScreenWidth, H := A_ScreenHeight
    Res := {Green: [], All: [], Edges: Map("L", false, "R", false, "U", false, "D", false)}

    Loop Parse FileRead(SkillOutFile), "`n", "`r"
    {
        if !RegExMatch(A_LoopField, "^([GM]),(\d+),(\d+)$", &Mt)
            continue
        X := Mt[2] + 0, Y := Mt[3] + 0
        Res.All.Push([X, Y])

        if (Mt[1] = "G" && X >= NodeEdgeMargin && Y >= NodeEdgeMargin
            && X <= W - NodeEdgeMargin && Y <= H - NodeEdgeMargin)
            Res.Green.Push([X, Y])

        if (X < SkillEdgeBand)
            Res.Edges["L"] := true
        if (X > W - SkillEdgeBand)
            Res.Edges["R"] := true
        if (Y < SkillEdgeBand)
            Res.Edges["U"] := true
        if (Y > H - SkillEdgeBand)
            Res.Edges["D"] := true
    }
    return Res
}

; Is the level box at (BX, BY) still showing green (not maxed) text?
BoxIsGreen(BX, BY)
{
    global LevelTextColor, LevelTextTol
    return PixelSearch(&fx, &fy, BX - 30, BY - 7, BX + 30, BY + 7, LevelTextColor, LevelTextTol)
}

; ---------- upgrading ----------

; Returns levels gained, 0 if the button was there but nothing changed,
; -1 if the node / Upgrade button couldn't be found,
; -2 if the cost isn't skill points (only when CheckUpgradeCost is on),
; -3 if the node belongs to a blocked branch colour (e.g. light blue),
; -4 if it's a purple node and PurpleAllowed() says no.
UpgradeNode(BX, BY)
{
    global MaxUpgradesPerNode, UpgradeWaitMs, SkillAbort
    global CheckUpgradeCost, UpgradeGapMs, UpgradeBurstClicks, PurpleBranchColor, BlockedBranchTol

    if !BoxIsGreen(BX, BY)          ; covered by a popup, or already maxed
        return -1

    Btn := OpenNodePopup(BX, BY)
    if !Btn
        return -1

    ; Which branch is it? The popup's category band is the branch colour.
    Band := FindBand(Btn[3], Btn[4])
    BandColor := IsObject(Band) ? Band.Color : -1
    if IsBlockedColor(BandColor)
        return -3
    if (BandColor != -1 && ColorNear(BandColor, PurpleBranchColor, BlockedBranchTol) && !PurpleAllowed())
        return -4

    ; Optional: only spend skill points ("Upgrade (-2 pt)")
    if (CheckUpgradeCost && !RegExMatch(ReadButtonText(Btn[3], Btn[4]), "i)\d+\s*pts?\b"))
        return -2

    ; Spam the Upgrade button until the node stops changing (= MAX or out of
    ; points) or the button disappears. No closing/reopening between levels.
    ; Progress is watched on the popup's own "LV x/y" text as well as the
    ; node's box (near the top of the screen the popup covers the box).
    Gained := 0
    Retried := false
    Clicks := 0
    Last := ProgressCRC(BX, BY, Btn, Band)
    LastChange := A_TickCount

    while (Clicks < MaxUpgradesPerNode * 8)
    {
        if SkillAbort
            break

        ; Burst of clicks before looking at the screen again
        Loop UpgradeBurstClicks
        {
            Click(Btn[1], Btn[2])
            Clicks++
            Sleep(UpgradeGapMs)
        }
        Sleep(100)                      ; let the popup catch up

        Now := ProgressCRC(BX, BY, Btn, Band)
        if (Now != Last)
        {
            Last := Now
            LastChange := A_TickCount
            Gained++
        }

        ; Button can flicker while the game processes clicks - only treat it
        ; as gone if it's still missing a moment later.
        Gone := !ButtonStillThere(Btn)
        if Gone
        {
            Sleep(250)
            Gone := !ButtonStillThere(Btn)
        }

        if Gone
        {
            ; Button gone. Either the node is MAXED, or the popup closed by
            ; itself (buying a frontier node unlocks new nodes and redraws the
            ; tree). Looking at the screen can't reliably tell these apart -
            ; a popup that folds DOWN sits on its own node, which is the same
            ; colour as the popup band - so always reopen the node and check
            ; for a button. No button after reopening = maxed.
            Sleep(150)
            Btn := OpenNodePopup(BX, BY)
            if !Btn
                break                   ; reopened and no button = maxed
            Band := FindBand(Btn[3], Btn[4])
            Last := ProgressCRC(BX, BY, Btn, Band)
            LastChange := A_TickCount
        }

        if (A_TickCount - LastChange > UpgradeWaitMs)
        {
            ; nothing changing any more
            if (Gained > 0 || Retried)
                break                   ; maxed, or can't afford more
            ; never changed at all - reopen once in case the popup was stale
            Retried := true
            Btn := OpenNodePopup(BX, BY)
            if !Btn
                break
            Band := FindBand(Btn[3], Btn[4])
            Last := ProgressCRC(BX, BY, Btn, Band)
            LastChange := A_TickCount
        }
    }
    return Gained
}

; Checksum of everything that changes when a level is bought:
; the popup's "LV x/y" text (always visible) plus the node's own box.
ProgressCRC(BX, BY, Btn, Band)
{
    C := RegionCRC(BX - 30, BY - 7, 60, 14)
    if IsObject(Band)
        C := C ^ RegionCRC(Btn[3] + 140, Band.Y - 15, 100, 16)
    return C
}

; Is a green button still at that spot? Loose check - the button changes
; shade while the mouse is hovering it.
ButtonStillThere(Btn)
{
    C := Integer(PixelGetColor(Btn[3] + 200, Btn[4] + 6))
    R := (C >> 16) & 0xFF, G := (C >> 8) & 0xFF, B := C & 0xFF
    return (G > R + 25 && G > B + 15)
}

; Click the node and return its Upgrade button (see FindUpgradeButton), or "".
; If the first click closed an already-open popup, the second click reopens it.
OpenNodePopup(BX, BY)
{
    global NodeClickOffsetY
    Loop 2
    {
        Click(BX, BY - NodeClickOffsetY)
        Sleep(300)
        Btn := FindUpgradeButton(BX, BY)
        if Btn
            return Btn
        Sleep(150)
    }
    return ""
}

; Should purple (rebirth-cost) nodes be bought right now?
; Currently: always. Later this can check spare rebirths, e.g.
;   return CurrentRebirth >= PurpleCost + RequiredRebirths(CurrentAscension)
PurpleAllowed()
{
    return true
}

IsBlockedColor(C)
{
    global BlockedBranchColors, BlockedBranchTol
    if (C = -1)
        return false
    for Blocked in BlockedBranchColors
        if ColorNear(C, Blocked, BlockedBranchTol)
            return true
    return false
}

; Walks up from the Upgrade button through the popup body (grey/white text)
; to the first coloured pixel - the category band, which is the branch colour.
; Returns {Color: 0xRRGGBB, Y: bottom edge of the band}, or "" if not found.
FindBand(FX, FY)
{
    X := FX + 60
    H := Min(260, FY - 6)
    if (H < 20)
        return ""

    Top := FY - 6 - H
    Col := CaptureColumn(X, Top, H)            ; top -> bottom
    i := Col.Length
    while (i >= 1)                             ; bottom (just above button) -> up
    {
        C := Col[i]
        R := (C >> 16) & 0xFF, G := (C >> 8) & 0xFF, B := C & 0xFF
        if (Max(R, G, B) - Min(R, G, B) > 35 && Max(R, G, B) > 50)
            return {Color: C, Y: Top + i - 1}
        i--
    }
    return ""
}

; Returns an array of 0xRRGGBB colours for a 1px-wide vertical strip
CaptureColumn(X, Y, H)
{
    hdcScreen := DllCall("GetDC", "Ptr", 0, "Ptr")
    hdcMem := DllCall("CreateCompatibleDC", "Ptr", hdcScreen, "Ptr")

    bi := Buffer(40, 0)
    NumPut("UInt", 40, bi, 0)
    NumPut("Int", 1, bi, 4)
    NumPut("Int", -H, bi, 8)
    NumPut("UShort", 1, bi, 12)
    NumPut("UShort", 32, bi, 14)

    pBits := 0
    hbm := DllCall("CreateDIBSection", "Ptr", hdcMem, "Ptr", bi, "UInt", 0
        , "Ptr*", &pBits, "Ptr", 0, "UInt", 0, "Ptr")
    old := DllCall("SelectObject", "Ptr", hdcMem, "Ptr", hbm, "Ptr")
    DllCall("BitBlt", "Ptr", hdcMem, "Int", 0, "Int", 0, "Int", 1, "Int", H
        , "Ptr", hdcScreen, "Int", X, "Int", Y, "UInt", 0x00CC0020)

    Out := []
    Loop H
        Out.Push(NumGet(pBits, (A_Index - 1) * 4, "UInt") & 0xFFFFFF)   ; BGRA -> 0xRRGGBB

    DllCall("SelectObject", "Ptr", hdcMem, "Ptr", old)
    DllCall("DeleteObject", "Ptr", hbm)
    DllCall("DeleteDC", "Ptr", hdcMem)
    DllCall("ReleaseDC", "Ptr", 0, "Ptr", hdcScreen)
    return Out
}

; The popup usually appears above the node (below it near the top of the
; screen, and shifted sideways near the screen edges).
; Returns [clickX, clickY, buttonLeft, buttonTop], or "" if none is visible.
FindUpgradeButton(BX, BY)
{
    global UpgradeBtnColor, UpgradeBtnTol

    Regions := [[BX - 550, BY - 450, BX + 550, BY - 30]
              , [BX - 550, BY + 15,  BX + 550, BY + 450]]

    for R in Regions
    {
        X1 := Max(R[1], 0), Y1 := Max(R[2], 0)
        X2 := Min(R[3], A_ScreenWidth - 1), Y2 := Min(R[4], A_ScreenHeight - 1)
        if (X2 <= X1 || Y2 <= Y1)
            continue

        if PixelSearch(&fx, &fy, X1, Y1, X2, Y2, UpgradeBtnColor, UpgradeBtnTol)
        {
            ; The real button is ~230px wide - check further along the same row
            if ColorNear(PixelGetColor(fx + 150, fy + 6), UpgradeBtnColor, UpgradeBtnTol + 6)
                return [fx + 110, fy + 15, fx, fy]
        }
    }
    return ""
}

; OCR the text on the Upgrade button, e.g. "Upgrade (-2 pt)"
ReadButtonText(FX, FY)
{
    global BtnPSFile, BtnImage, BtnBase, CSFile, Tesseract

    if FileExist(BtnBase ".txt")
        FileDelete(BtnBase ".txt")

    Cmd := 'powershell.exe -NoProfile -ExecutionPolicy Bypass -File "' BtnPSFile '"'
        . ' -X ' (FX - 20) ' -Y ' (FY - 2) ' -W 280 -H 36'
        . ' -Out "' BtnImage '" -Cs "' CSFile '"'
        . ' -Tess "' OcrTessArg() '" -OutBase "' BtnBase '"'

    RunWait(Cmd, , "Hide")
    return FileExist(BtnBase ".txt") ? Trim(FileRead(BtnBase ".txt"), " `t`r`n") : ""
}

ColorNear(C1, C2, Tol)
{
    C1 := Integer(C1), C2 := Integer(C2)
    return Abs(((C1 >> 16) & 0xFF) - ((C2 >> 16) & 0xFF)) <= Tol
        && Abs(((C1 >> 8) & 0xFF) - ((C2 >> 8) & 0xFF)) <= Tol
        && Abs((C1 & 0xFF) - (C2 & 0xFF)) <= Tol
}

; Fast checksum of a small screen area - used to tell if a level number changed
RegionCRC(X, Y, W, H)
{
    hdcScreen := DllCall("GetDC", "Ptr", 0, "Ptr")
    hdcMem := DllCall("CreateCompatibleDC", "Ptr", hdcScreen, "Ptr")

    bi := Buffer(40, 0)
    NumPut("UInt", 40, bi, 0)
    NumPut("Int", W, bi, 4)
    NumPut("Int", -H, bi, 8)
    NumPut("UShort", 1, bi, 12)
    NumPut("UShort", 32, bi, 14)

    pBits := 0
    hbm := DllCall("CreateDIBSection", "Ptr", hdcMem, "Ptr", bi, "UInt", 0
        , "Ptr*", &pBits, "Ptr", 0, "UInt", 0, "Ptr")
    old := DllCall("SelectObject", "Ptr", hdcMem, "Ptr", hbm, "Ptr")

    DllCall("BitBlt", "Ptr", hdcMem, "Int", 0, "Int", 0, "Int", W, "Int", H
        , "Ptr", hdcScreen, "Int", X, "Int", Y, "UInt", 0x00CC0020)

    crc := DllCall("ntdll\RtlComputeCrc32", "UInt", 0, "Ptr", pBits, "UInt", W * H * 4, "UInt")

    DllCall("SelectObject", "Ptr", hdcMem, "Ptr", old)
    DllCall("DeleteObject", "Ptr", hbm)
    DllCall("DeleteDC", "Ptr", hdcMem)
    DllCall("ReleaseDC", "Ptr", 0, "Ptr", hdcScreen)
    return crc
}

; ==========================================
; MODE SWITCH + AUTO RB
; ==========================================

SetMacroMode(Mode)
{
    global MacroMode, Running, SkillBusy, SkillAbort, WH_Start
    if (Mode = MacroMode)
        return
    MacroMode := Mode
    SaveSetting("MacroMode")

    if (MacroMode = "Rebirth")
    {
        if SkillBusy
            SkillAbort := true              ; rebirth mode never uses the tree
        if Running
            SetTimer(() => EnsureAutoRBOn(), -1)
    }

    if WH_Start
        Notify("Switched to " MacroMode " mode", RebirthSummary(), 0xB8A2FF)
    UpdateDashboard()
}

AutoRBIsOn()
{
    global AutoRBRegion, AutoRBColor
    R := AutoRBRegion
    return PixelSearch(&fx, &fy, R[1], R[2], R[3], R[4], AutoRBColor, 10)
}

; Click the Auto RB button until it's in the wanted state. Returns true on success.
SetAutoRB(On)
{
    global AutoRBClickXY
    Loop 3
    {
        if (AutoRBIsOn() = On)
            return true
        Click(AutoRBClickXY[1], AutoRBClickXY[2])
        Sleep(500)
    }
    return (AutoRBIsOn() = On)
}

; Rebirth mode: make sure the game keeps rebirthing
EnsureAutoRBOn()
{
    global MacroMode, Running, SkillBusy, ChatBusy
    if (MacroMode != "Rebirth" || !Running || SkillBusy)
        return
    HoldClicks("autorb")
    while ChatBusy
        Sleep(50)
    Sleep(150)
    FocusRoblox()
    SetAutoRB(true)
    ReleaseClicks("autorb")
}

; ==========================================
; SETTINGS MENU (dashboard button)
; ==========================================

; ---------- SETTINGS WINDOW ----------

; Friendlier names for the settings window (anything missing is auto-named)
SettingLabels := Map(
    "MacroMode", "Mode", "OpenModeIndex", "Case open mode", "Point2", "Results OK click (x,y)",
    "Point3", "Ground / melee click (x,y)", "ClickDelay", "Click delay (ms)",
    "ChatMessage", "Chat message", "Chat_Interval", "Chat every (ms)", "OCR_Interval", "Scan every (ms)",
    "OCREngine", "OCR engine (backup reader)", "UserChatTimeout", "Pause clicks when you type (ms)",
    "UseM1Lock", "Keep M1 held (ESC trick)", "M1EscDelayMs", "Wait before 2nd ESC (ms)",
    "M1RelockMs", "Re-lock every (ms, 0 = off)",
    "WebhookURL", "Webhook URL", "WebhookName", "Bot name", "WebhookMention", "Ping (e.g. <@id>)",
    "WH_Start", "Post: start / pause / close", "WH_Rebirth", "Post: each rebirth",
    "WH_Ascension", "Post: ascended", "WH_AscendReady", "Post: ascend ready (ping)",
    "WH_SkillTree", "Post: skill tree", "WH_Errors", "Post: errors (ping)",
    "WH_DayNight", "Post: day / night changes", "WH_Restart", "Post: new game",
    "WH_Equip", "Post: re-equips", "WH_Cosmetics", "Post: Cosmetics reopened",
    "OCRErrorAlertAfter", "Alert after N failed scans",
    "SkillTreeKey", "Key that opens the tree", "CheckUpgradeCost", "Only buy if cost is 'pt'",
    "UpgradeGapMs", "Gap between upgrade clicks (ms)", "UpgradeBurstClicks", "Clicks per burst",
    "MaxUpgradesPerNode", "Max levels per node", "OutOfPointsAfter", "Out of points after N nodes",
    "BlockedBranchColors", "Blocked branch colours (hex)", "SkillAutoCalibrate", "Auto-calibrate panning",
    "SkillPanTarget", "Pan step (fraction of screen)", "SkillPanMs", "Pan key hold (ms)",
    "SkillMaxViews", "Max views per run", "SkillMaxRadius", "Max steps from centre",
    "SkillPassesPerView", "Rescans per view", "CloseCosmeticsFirst", "Close Cosmetics first",
    "NodeClickOffsetY", "Node click offset above box (px)",
    "AutoRestart", "Auto new game on low day", "RestartMaxDay", "Restart at day <=",
    "MenuStepMs", "Wait between menu clicks (ms)", "PlayClicks", "Min PLAY clicks",
    "PlayClickGapMs", "Gap between PLAY clicks (ms)", "RestartLoadMs", "Load wait after deploy (ms)",
    "RestartCooldownMs", "Retry cooldown (ms)",
    "KeepEquipped", "Keep weapon equipped", "EquipWeapon", "Weapon",
    "EquipFindMs", "Re-find slot every (ms)", "EquipCheckMs", "Check equipped every (ms)",
    "KeepCosmeticsOpen", "Keep Cosmetics open", "CosmeticsCheckMs", "Check Cosmetics every (ms)"
)
BoolSettings := "|UseM1Lock|KeepEquipped|KeepCosmeticsOpen|AutoRestart|CheckUpgradeCost|SkillAutoCalibrate|CloseCosmeticsFirst|"

SettingsPages := ["General", "Equip", "Advanced", "Test"]
SettingsPageTitles := Map("General", "General", "Equip", "Equip / M1", "Advanced", "Advanced", "Test", "Test")
AdvancedSections := ["Webhook", "SkillTree", "NewGame", "Detection", "Positions"]
AdvancedTitles := ["Webhook", "Skill Tree", "New Game", "Detection", "Positions"]
AdvSectionDDL := ""
AdvCurrent := "Webhook"
SettingsGui := ""
SettingsCtrls := Map()          ; setting name -> control
SettingsPageCtrls := Map()      ; page -> [controls]
SettingsTabBtns := Map()
SkillTestBtn := ""

PrettySettingName(N)
{
    T := RegExReplace(N, "^WH_", "Post: ")
    T := StrReplace(T, "_", " ")
    T := RegExReplace(T, "([a-z])([A-Z])", "$1 $2")
    T := RegExReplace(T, "XY$", " (x,y)")
    T := RegExReplace(T, " ?Ms$", " (ms)")
    return T
}

BuildSettingsWindow()
{
    global
    local G, i, Page, Btn, Y, Item, Items, P, Names, Div, Warn
    G := Gui("+AlwaysOnTop +Owner" Dashboard.Hwnd, "Unsungrinder - Settings")
    G.BackColor := "202431"
    G.SetFont("s10 cFFFFFF", "Segoe UI")
    SettingsGui := G

    ; tab buttons
    for i, Page in SettingsPages
    {
        Btn := G.AddButton("x" (15 + (i - 1) * 131) " y12 w125 h28", SettingsPageTitles[Page])
        Btn.OnEvent("Click", ShowSettingsPage.Bind(Page))
        SettingsTabBtns[Page] := Btn
        SettingsPageCtrls[Page] := []
    }
    G.AddText("x15 y50 w520 h1 Background3A3F55")

    ; General
    AddSettingRows(G, "General", SettingsLayout["General"], 64, 28)

    ; Equip / M1 (+ Cosmetics)
    Names := SettingsLayout["Equip"].Clone()
    for Item in SettingsLayout["Cosmetics"]
        Names.Push(Item)
    for Item in SettingsLayout["M1Lock"]
        Names.Push(Item)
    AddSettingRows(G, "Equip", Names, 64, 28)

    ; Advanced: a section dropdown, then that section's settings
    Warn := G.AddText("x20 y58 w510 h20 cFF5555", "Warning: don't change these unless you know what you're doing.")
    P := G.AddText("x20 y83 w235 h20 cBBBBBB", "Section")
    G.SetFont("c000000")
    AdvSectionDDL := G.AddDropDownList("x260 y80 w270", AdvancedTitles)
    G.SetFont("cFFFFFF")
    AdvSectionDDL.OnEvent("Change", (Ctrl, *) => ShowAdvancedSection(AdvancedSections[Ctrl.Value]))
    Div := G.AddText("x15 y112 w520 h1 Background3A3F55")
    SettingsPageCtrls["Advanced"].Push(Warn, P, AdvSectionDDL, Div)
    for Item in AdvancedSections
    {
        SettingsPageCtrls["Adv:" Item] := []
        AddSettingRows(G, "Adv:" Item, SettingsLayout[Item], 120, 25)
    }

    ; Test
    Y := 68
    Items := [["Send test webhook", "Posts a test message to your Discord webhook.", (*) => TestWebhook()]
            , ["Run skill tree now", "Runs the skill tree routine once (ignores the rebirth requirement). Press again to stop.", (*) => ToggleSkillTree()]
            , ["Send chat now", "Sends one chat message, even while paused.", (*) => ForceChat()]
            , ["Start a new game now", "Runs the whole new-game routine (main menu -> Day 50 -> deploy).", (*) => TestNewGame()]
            , ["Teach A / R", "Type your current A and R once - the macro learns the digit shapes on screen.", (*) => TeachAR()]]
    for Item in Items
    {
        Btn := G.AddButton("x20 y" Y " w180 h30", Item[1])
        Btn.OnEvent("Click", Item[3])
        P := G.AddText("x210 y" (Y + 1) " w320 h32 cAAAAAA", Item[2])
        SettingsPageCtrls["Test"].Push(Btn, P)
        if (Item[1] = "Run skill tree now")
            SkillTestBtn := Btn
        Y += 46
    }

    ; bottom bar
    G.AddText("x15 y716 w520 h1 Background3A3F55")
    Btn := G.AddButton("x15 y728 w100 h30", "Save")
    Btn.OnEvent("Click", (*) => SaveSettingsWindow(false))
    Btn := G.AddButton("x120 y728 w120 h30", "Save + Restart")
    Btn.OnEvent("Click", (*) => SaveSettingsWindow(true))
    Btn := G.AddButton("x245 y728 w70 h30", "Export")
    Btn.OnEvent("Click", (*) => ExportSettings())
    Btn := G.AddButton("x320 y728 w70 h30", "Import")
    Btn.OnEvent("Click", (*) => ImportSettings())
    Btn := G.AddButton("x395 y728 w65 h30", "File")
    Btn.OnEvent("Click", (*) => Run('notepad.exe "' SettingsFile '"'))
    Btn := G.AddButton("x465 y728 w70 h30", "Reset")
    Btn.OnEvent("Click", (*) => ResetSettings())
    G.AddText("x15 y764 w520 h20 c888888", "Timing changes take effect the next time you press F1.")
    G.AddText("x15 y786 w520 h20 c6A7090", "Unsungrinder v" AppVersion " - made by Equinoxiiq.  Questions / inquiries: @equinoxi_q on Discord")
}

; One label + control row per setting
AddSettingRows(G, Page, Names, Y, RowH)
{
    global SettingLabels, SettingsPageCtrls, SettingsCtrls, OpenModes, WeaponPatterns
    for Name in Names
    {
        Lbl := SettingLabels.Has(Name) ? SettingLabels[Name] : PrettySettingName(Name)
        if IsBoolSetting(Name)
        {
            C := G.AddCheckbox("x20 y" Y " w500 h22 -Theme cFFFFFF", Lbl)
            SettingsPageCtrls[Page].Push(C)
        }
        else
        {
            T := G.AddText("x20 y" (Y + 3) " w235 h20 cBBBBBB", Lbl)
            SettingsPageCtrls[Page].Push(T)
            if (Name = "MacroMode")
            {
                G.SetFont("c000000")
                C := G.AddDropDownList("x260 y" Y " w270", ["Ascension", "Rebirth"])
                G.SetFont("cFFFFFF")
            }
            else if (Name = "OCREngine")
            {
                G.SetFont("c000000")
                C := G.AddDropDownList("x260 y" Y " w270", ["windows", "tesseract"])
                G.SetFont("cFFFFFF")
            }
            else if (Name = "OpenModeIndex")
            {
                L := []
                for M in OpenModes
                    L.Push(M.Name)
                G.SetFont("c000000")
                C := G.AddDropDownList("x260 y" Y " w270", L)
                G.SetFont("cFFFFFF")
            }
            else if (Name = "EquipWeapon")
            {
                L := []
                for W, Pat in WeaponPatterns
                    L.Push(W)
                G.SetFont("c000000")
                C := G.AddDropDownList("x260 y" Y " w270", L)
                G.SetFont("cFFFFFF")
            }
            else
                C := G.AddEdit("x260 y" Y " w270 h" (RowH - 4) " Background2A2F40 cFFFFFF")
            SettingsPageCtrls[Page].Push(C)
        }
        SettingsCtrls[Name] := C
        Y += RowH
    }
}

ShowAdvancedSection(Section)
{
    global AdvancedSections, SettingsPageCtrls, AdvCurrent, AdvSectionDDL
    AdvCurrent := Section
    for S in AdvancedSections
        for C in SettingsPageCtrls["Adv:" S]
            C.Visible := (S = Section)
    for i, S in AdvancedSections
        if (S = Section)
            AdvSectionDDL.Choose(i)
}

ShowSettingsWindow()
{
    global SettingsGui, Dashboard
    if !IsObject(SettingsGui)
        BuildSettingsWindow()
    FillSettingsWindow()
    ShowSettingsPage("General")
    Dashboard.GetPos(&DX, &DY)
    SettingsGui.Show("x" Max(0, DX - 560) " y" Max(0, DY - 60) " w550 h812")
}

ShowSettingsPage(Page, *)
{
    global SettingsPages, SettingsPageCtrls, SettingsTabBtns, AdvancedSections, AdvCurrent
    for P in SettingsPages
        for C in SettingsPageCtrls[P]
            C.Visible := false
    for S in AdvancedSections
        for C in SettingsPageCtrls["Adv:" S]
            C.Visible := false
    for C in SettingsPageCtrls[Page]
        C.Visible := true
    if (Page = "Advanced")
        ShowAdvancedSection(AdvCurrent)
    for P, B in SettingsTabBtns
        B.Text := (P = Page ? "> " : "") RegExReplace(B.Text, "^> ", "")
}

; current values -> controls
FillSettingsWindow()
{
    global
    local Name, C
    for Name, C in SettingsCtrls
    {
        if IsBoolSetting(Name)
            C.Value := %Name% ? 1 : 0
        else if (Name = "MacroMode")
            C.Choose(MacroMode = "Rebirth" ? 2 : 1)
        else if (Name = "OCREngine")
            C.Choose(OCREngine = "tesseract" ? 2 : 1)
        else if (Name = "OpenModeIndex")
            C.Choose(OpenModeIndex)
        else if (Name = "EquipWeapon")
            C.Choose(EquipWeapon)
        else
            C.Value := SettingToText(Name, %Name%)
    }
}

; controls -> settings (live) + file
SaveSettingsWindow(Restart)
{
    global
    local Name, C, V
    for Name, C in SettingsCtrls
    {
        if IsBoolSetting(Name)
            %Name% := C.Value ? true : false
        else if (Name = "MacroMode")
            SetMacroMode(C.Text)
        else if (Name = "OCREngine")
            OCREngine := C.Text
        else if (Name = "OpenModeIndex")
            SetOpenMode(C.Value)
        else if (Name = "EquipWeapon")
        {
            if (C.Text != EquipWeapon)
                SetWeapon(C.Text)
        }
        else
            %Name% := TextToSetting(%Name%, Trim(C.Value))
    }
    SaveAllSettings()
    UpdateDashboard()
    if Restart
        Reload()
    else
        ToolTip("Settings saved"), SetTimer(() => ToolTip(), -1500)
}

SetWeapon(Name)
{
    global EquipWeapon, WeaponPatterns, EquipNameRegex, EquipSlot, EquipFoundTick, EquipCaption
    if !WeaponPatterns.Has(Name)
        return
    EquipWeapon := Name
    EquipNameRegex := WeaponPatterns[Name]
    EquipSlot := 0                          ; find the new weapon's slot
    EquipFoundTick := -999999
    EquipCaption.Text := "WEAPON: " StrUpper(Name) " (slot ?)"
}

IsBoolSetting(Name)
{
    global BoolSettings
    return InStr(BoolSettings, "|" Name "|") || (SubStr(Name, 1, 3) = "WH_")
}

; skill tree test button label follows the routine
UpdateSkillTestBtn()
{
    global SkillTestBtn, SkillBusy
    if IsObject(SkillTestBtn)
        SkillTestBtn.Text := SkillBusy ? "Stop skill tree" : "Run skill tree now"
}
SetTimer(UpdateSkillTestBtn, 500)

ExportSettings()
{
    global SettingsFile
    Dest := FileSelect("S16", A_Desktop "\unsungrinder_settings.ini", "Export settings", "Settings (*.ini)")
    if (Dest = "")
        return
    if !RegExMatch(Dest, "i)\.ini$")
        Dest .= ".ini"
    SaveAllSettings()
    FileCopy(SettingsFile, Dest, true)
    ; don't hand out your webhook unless you want to
    if (MsgBox("Include your Discord webhook URL and ping in the exported file?", "Export settings", "YesNo Icon?") = "No")
    {
        IniWrite("", Dest, "Webhook", "WebhookURL")
        IniWrite("", Dest, "Webhook", "WebhookMention")
    }
    MsgBox("Settings exported to:`n" Dest, "Export settings")
}

ImportSettings()
{
    global SettingsFile
    Src := FileSelect(1, A_Desktop, "Import settings", "Settings (*.ini)")
    if (Src = "")
        return
    if (IniRead(Src, "General", "MacroMode", "") = "")
    {
        MsgBox("That doesn't look like an Unsungrinder settings file.", "Import settings", "Icon!")
        return
    }
    ; keep your own webhook if the imported file doesn't have one
    MyHook := IniRead(SettingsFile, "Webhook", "WebhookURL", "")
    MyPing := IniRead(SettingsFile, "Webhook", "WebhookMention", "")
    FileCopy(Src, SettingsFile, true)
    if (IniRead(SettingsFile, "Webhook", "WebhookURL", "") = "" && MyHook != "")
    {
        IniWrite(MyHook, SettingsFile, "Webhook", "WebhookURL")
        IniWrite(MyPing, SettingsFile, "Webhook", "WebhookMention")
    }
    MsgBox("Settings imported - the script will now restart to apply them.", "Import settings")
    Reload()
}

ResetSettings()
{
    global SettingsFile
    if (MsgBox("Reset every setting to its default? (Your webhook URL will be cleared too.)", "Reset settings", "YesNo Icon!") != "Yes")
        return
    FileDelete(SettingsFile)
    Reload()
}

; ==========================================
; DISCORD WEBHOOK
; ==========================================

TestWebhook()
{
    global WebhookURL
    if (WebhookURL = "")
    {
        MsgBox("No webhook set - paste your Discord webhook URL in Settings > Webhook, then Save.", "Test webhook")
        return
    }
    Notify("Test message", "Webhook is working.`n" RebirthSummary(), 0xB8A2FF)
}

; Posts rebirth / ascension / ascend-ready messages when the values change
WebhookProgressEvents()
{
    global CurrentRebirth, CurrentAscension, AscendReady
    global LastPostedR, LastPostedA, PendingR, WasAscendReady
    global WH_Rebirth, WH_Ascension, WH_AscendReady

    R := CurrentRebirth, A := CurrentAscension

    ; First reading - just remember it
    if (LastPostedR = "")
    {
        LastPostedR := R, LastPostedA := A, WasAscendReady := AscendReady
        return
    }

    ; Ascension changed (R normally resets too)
    if (A != "Unknown" && LastPostedA != "Unknown" && A != LastPostedA)
    {
        if WH_Ascension
            Notify("Ascended! A" LastPostedA " -> A" A, RebirthSummary(), 0xFFC81E)
        LastPostedA := A, LastPostedR := R, PendingR := ""
        WasAscendReady := AscendReady
        return
    }
    if (LastPostedA = "Unknown" && A != "Unknown")
        LastPostedA := A

    ; New rebirth - must be read twice in a row to ignore OCR misreads
    if (R != LastPostedR)
    {
        if (PendingR = R)
        {
            if (WH_Rebirth && R > LastPostedR)
                Notify("Rebirth R" R, RebirthSummary(), 0xFF78E6)
            LastPostedR := R
            PendingR := ""
        }
        else
            PendingR := R
    }
    else
        PendingR := ""

    if (AscendReady && !WasAscendReady && WH_AscendReady)
        Notify("Ascend ready!", "Reached R" R " - requirement for A" A " is R" RequiredRebirths(A) ".", 0x55DD88, true)
    WasAscendReady := AscendReady
}

OCRFailed(Reason)
{
    global OCRFailStreak, OCRAlertSent, OCRErrorAlertAfter, WH_Errors, Running
    OCRFailStreak++
    if (Running && WH_Errors && !OCRAlertSent && OCRFailStreak >= OCRErrorAlertAfter)
    {
        OCRAlertSent := true
        Notify("Rebirth reading is failing", OCRFailStreak " scans in a row failed (" Reason ").`nChat may be hidden or Roblox not in focus.", 0xFF5555, true)
    }
}

RebirthSummary()
{
    global CurrentRebirth, CurrentAscension
    A := CurrentAscension, R := CurrentRebirth
    Txt := ((A = "Unknown") ? "A?" : "A" A) "  " ((R = "Unknown") ? "R?" : "R" R)
    if (A != "Unknown")
        Txt .= "  (ascend at R" RequiredRebirths(A) ")"
    return Txt
}

; Sends one embed to the webhook. Async so the macro never waits on Discord.
Notify(Title, Desc := "", Color := 0xB8A2FF, Ping := false, Async := true)
{
    global WebhookURL, WebhookName, WebhookMention

    if (WebhookURL = "")
        return

    Content := (Ping && WebhookMention != "") ? WebhookMention : ""
    Stamp := FormatTime(A_NowUTC, "yyyy-MM-dd'T'HH:mm:ss'Z'")

    Body := '{"username":"' JsonEscape(WebhookName) '"'
        . ',"content":"' JsonEscape(Content) '"'
        . ',"embeds":[{"title":"' JsonEscape(Title) '"'
        . ',"description":"' JsonEscape(Desc) '"'
        . ',"color":' (Color + 0)
        . ',"timestamp":"' Stamp '"}]}'

    PostWebhook(Body, Async)
}

PostWebhook(Body, Async := true)
{
    global WebhookURL, WH_Pending
    try
    {
        Req := ComObject("WinHttp.WinHttpRequest.5.1")
        Req.Open("POST", WebhookURL, Async)
        Req.SetRequestHeader("Content-Type", "application/json; charset=utf-8")
        Req.Send(Body)
        if Async
        {
            ; keep the request object alive until it's had time to finish
            WH_Pending.Push({Req: Req, Time: A_TickCount})
            SetTimer(CleanupWebhooks, 5000)
        }
    }
}

CleanupWebhooks()
{
    global WH_Pending
    Keep := []
    for P in WH_Pending
        if (A_TickCount - P.Time < 20000)
            Keep.Push(P)
    WH_Pending := Keep
    if !WH_Pending.Length
        SetTimer(CleanupWebhooks, 0)
}

JsonEscape(Str)
{
    Str := StrReplace(Str, "\", "\\")
    Str := StrReplace(Str, '"', '\"')
    Str := StrReplace(Str, "`r", "")
    Str := StrReplace(Str, "`n", "\n")
    Str := StrReplace(Str, "`t", "\t")
    return Str
}

; Post "closed" when the script exits (sent synchronously so it gets out)
WebhookOnExit(*)
{
    global WH_Start
    if WH_Start
        Notify("Macro closed", RebirthSummary(), 0x888888, false, false)
}
OnExit(WebhookOnExit)

; ==========================================
; PIXEL TAG READER (learning)
; ==========================================

LastGlyphR := "", LastGlyphA := "", LastGlyphRP := "", LastGlyphAP := ""

; Seed digit shapes (bold chat-tag font at 1920x1080). More are learned.
WriteSeedGlyphs()
{
    global GlyphFile
    if FileExist(GlyphFile)
        return
    Seed := "
    (
3:7:10:0111110110011000000100000110001110000001100000011000001111111100111100
3:7:10:0111110110011000000100000110001110000001100000011100001111111100111100
2:7:10:0111110110011000000100000010000011000011000011000011000011111111111111
1:4:10:0111111100110011001100110011001100110011
4:8:10:00011100000111000010010001100100010001001100010011111111000011100000010000000100
1:4:10:1111111100110011001100110011001100110011
9:7:10:0111110110001111000011100001110001101111110000110000011000011000011000
0:8:10:00111100011001101100001011000011100000111000001111000011010000100111111000111000
0:8:10:01111100011001101100001011000011100000111000001111000011110000100111111000111000
    )"
    FileOpen(GlyphFile, "w", "UTF-8").Write(Seed "`n")
}
WriteSeedGlyphs()

; Reads roblox_glyph.txt. R/A come back as numbers, or "" if unknown.
; A tag missing entirely -> A = "none".
ReadGlyphResult(&R, &A)
{
    global GlyphBase, LastGlyphR, LastGlyphA, LastGlyphRP, LastGlyphAP
    global CurrentRebirth, CurrentAscension
    R := "", A := ""
    if !FileExist(GlyphBase ".txt")
        return
    Txt := FileRead(GlyphBase ".txt")
    RD := RegExMatch(Txt, "m)^R=(.*)$", &M) ? Trim(M[1]) : ""
    AD := RegExMatch(Txt, "m)^A=(.*)$", &M) ? Trim(M[1]) : ""
    RP := RegExMatch(Txt, "m)^RP=(.*)$", &M) ? Trim(M[1]) : ""
    AP := RegExMatch(Txt, "m)^AP=(.*)$", &M) ? Trim(M[1]) : ""
    LastGlyphR := RD, LastGlyphA := AD, LastGlyphRP := RP, LastGlyphAP := AP

    if (RD = "")
        return                              ; no R tag on screen

    ; R
    if !InStr(RD, "?")
        R := RD + 0
    else if (CurrentRebirth != "Unknown")
    {
        ; R only counts up (1 per rebirth), so try the next values in order
        Cands := []
        if (CurrentAscension != "Unknown" && CurrentRebirth >= RequiredRebirths(CurrentAscension))
            Loop 3
                Cands.Push(A_Index - 1)     ; just ascended - R starts again
        Loop 3
            Cands.Push(CurrentRebirth + A_Index)
        R := LearnFromCandidates(RD, RP, Cands)
    }

    ; A
    if (AD = "")
        A := "none"
    else if !InStr(AD, "?")
        A := AD + 0
    else if (CurrentAscension != "Unknown")
        A := LearnFromCandidates(AD, AP, [CurrentAscension + 1])
}

; Digits like "3?" + their shapes: take the FIRST candidate value (in order)
; that fits - known digits must match, and a "?" can only be a digit whose
; shape isn't known yet. Saves the new shapes and returns the value.
LearnFromCandidates(Digits, Pats, Cands)
{
    global GlyphFile
    Known := ""
    if FileExist(GlyphFile)
        Loop Parse FileRead(GlyphFile), "`n", "`r"
            if RegExMatch(A_LoopField, "^(\d):", &M) && !InStr(Known, M[1])
                Known .= M[1]
    for C in Cands
    {
        S := C ""
        if (StrLen(S) != StrLen(Digits))
            continue
        Ok := true
        Loop StrLen(S)
        {
            D := SubStr(Digits, A_Index, 1), V := SubStr(S, A_Index, 1)
            if (D != "?" && D != V) || (D = "?" && InStr(Known, V))
                Ok := false
        }
        if Ok
        {
            LearnGlyphs(S, Pats, Digits)
            return S + 0
        }
    }
    return ""
}

; Save digit shapes. Only the "?" positions unless Mask is "" (teach all).
LearnGlyphs(Value, Pats, Mask := "")
{
    global GlyphFile
    P := StrSplit(Pats, ";")
    if (P.Length != StrLen(Value))
        return false
    Existing := FileExist(GlyphFile) ? FileRead(GlyphFile) : ""
    Changed := false
    Loop P.Length
    {
        if (Mask != "" && SubStr(Mask, A_Index, 1) != "?")
            continue
        F := StrSplit(P[A_Index], ",")
        if (F.Length != 3)
            continue
        Shape := ":" F[1] ":" F[2] ":" F[3]
        Line := SubStr(Value, A_Index, 1) Shape
        if InStr(Existing, Line)
            continue
        ; same shape saved under a different digit = an earlier wrong guess - replace it
        Existing := RegExReplace(Existing, "m)^\d" Shape "\R?", "")
        Existing := RTrim(Existing, "`r`n") "`n" Line "`n"
        Changed := true
    }
    if Changed
        FileOpen(GlyphFile, "w", "UTF-8").Write(LTrim(Existing, "`r`n"))
    return true
}

; Teach A / R (Settings > Test): tell the macro your current A and R once - it learns every digit
; shape on screen right now (useful at a new resolution / unseen digits).
TeachAR()
{
    global LastGlyphRP, LastGlyphAP, CurrentRebirth, CurrentAscension, CandRCount, CandACount
    IB := InputBox("Type your current Ascension and Rebirth, e.g.  2 33`n`n(The newest chat line must show your [A#][R#] tags - send a chat message first.)", "Teach A / R", "w360 h170")
    if (IB.Result != "OK" || !RegExMatch(IB.Value, "^\s*(\d+)\s+(\d+)\s*$", &M))
        return
    A := M[1] + 0, R := M[2] + 0
    OkR := LearnGlyphs(R "", LastGlyphRP)
    OkA := (A = 0) ? true : LearnGlyphs(A "", LastGlyphAP)
    CurrentRebirth := R, CurrentAscension := A
    CandRCount := 0, CandACount := 0
    UpdateDashboard()
    MsgBox((OkR && OkA) ? "Learned. A" A " R" R " saved." : "The digits on screen didn't match what you typed - send a chat message so the newest line shows your tags, then try again.", "Teach A / R")
}

; ==========================================
; OCR HELPERS
; ==========================================

; Path handed to the PowerShell scripts: "none" = use Windows OCR
OcrTessArg()
{
    global OCREngine, Tesseract
    ; "none" (not an empty string - powershell -File drops empty arguments)
    return (OCREngine = "tesseract" && FileExist(Tesseract)) ? Tesseract : "none"
}

; Only change R / A when the same new value is read twice in a row.
; A never goes down (only an ascension changes it, and that's always up),
; and "A0" (no A tag at all) is only believed after 4 scans without one
; while A is still unknown or already 0.
AcceptReading(R, A)
{
    global CurrentRebirth, CurrentAscension, CandR, CandRCount, CandA, CandACount, NoATagCount

    R := R + 0
    if (R = CurrentRebirth)
        CandRCount := 0
    else
    {
        CandRCount := (R = CandR) ? CandRCount + 1 : 1
        CandR := R
        if (CandRCount >= 2 || CurrentRebirth = "Unknown")
            CurrentRebirth := R, CandRCount := 0
    }

    if IsNumber(A)
    {
        NoATagCount := 0
        A := A + 0
        if (A = CurrentAscension)
            CandACount := 0
        else if (CurrentAscension = "Unknown" || A > CurrentAscension)
        {
            CandACount := (A = CandA) ? CandACount + 1 : 1
            CandA := A
            if (CandACount >= 2)
                CurrentAscension := A, CandACount := 0
        }
        ; lower than the known A = misread, ignored
    }
    else if (A = "none")
    {
        if (CurrentAscension = "Unknown" || CurrentAscension = 0)
        {
            if (++NoATagCount >= 4)
                CurrentAscension := 0
        }
    }
}

; Finds the newest (last) line with an R tag and pulls R and A out of it.
; Lines look like "[A1][R14] [LV 93] Name: msg"; a line with no A tag = A0.
ParseTags(Text, &FoundR, &FoundA)
{
    Text := FixTagDigits(Text)
    Loop Parse Text, "`n", "`r"
    {
        if !RegExMatch(A_LoopField, "\[?R(\d{1,4})\b", &MR)
            continue
        FoundR := MR[1]
        if RegExMatch(A_LoopField, "\[?A(\d{1,3})\]", &MA)
            FoundA := MA[1]
        else if RegExMatch(A_LoopField, "\[[A4]?(\d{1,2})\]\s*\[?R\d", &MA)
            FoundA := MA[1]         ; "[41][R14]" - the A read as a 4
        else if !RegExMatch(A_LoopField, "\[A")
            FoundA := "none"        ; no A tag on the line (could be A0 - or just missed)
        else
            FoundA := ""            ; garbled A - unknown
    }
}

; Fix common letter/number mix-ups inside [A#] / [R#] tags (I/l/| -> 1, O/o -> 0)
FixTagDigits(Txt)
{
    Out := "", Pos := 1
    static Fix := Map("I", "1", "l", "1", "|", "1", "i", "1", "O", "0", "o", "0", "Z", "2", "z", "2"
                    , "S", "5", "s", "5", "B", "8", "g", "9", "q", "9", "G", "6", "T", "7")
    while (P := RegExMatch(Txt, "([AR])\s?([0-9IlOo|iZzSsBgqGT]{1,5})(?=\])", &M, Pos))
    {
        D := ""
        Loop Parse M[2]
            D .= Fix.Has(A_LoopField) ? Fix[A_LoopField] : A_LoopField
        Out .= SubStr(Txt, Pos, P - Pos) M[1] D
        Pos := P + M.Len
    }
    return Out SubStr(Txt, Pos)
}

; ==========================================
; HELPER SCRIPTS (written once at startup)
; ==========================================

WriteHelperScripts()
{
    global PSFile, CSFile, SkillPSFile, BtnPSFile, TextPSFile, HotbarPSFile, OcrLibFile

    PSCode := "
    (
param([int]$X, [int]$Y, [int]$W, [int]$H, [string]$Out, [string]$Cs, [int]$Scale, [int]$Filter, [int]$PR, [int]$PG, [int]$PB, [int]$Tol, [int]$YR, [int]$YG, [int]$YB, [int]$YTol, [int]$YBTol, [string]$Tess, [string]$OutBase, [int]$DX, [int]$DY, [int]$DW, [int]$DH, [string]$DOut, [string]$DOutBase, [string]$Glyphs, [string]$GlyphOut)
. (Join-Path $PSScriptRoot 'roblox_ocrlib.ps1')
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition ([IO.File]::ReadAllText($Cs))
[void][OcrHelper]::SetProcessDPIAware()
$src = New-Object System.Drawing.Bitmap($W, $H)
$g = [System.Drawing.Graphics]::FromImage($src)
$g.CopyFromScreen($X, $Y, 0, 0, $src.Size)
$g.Dispose()
# Pixel-exact tag reader (no OCR) - matches each digit against known shapes
$templ = ''
if (Test-Path $Glyphs) { $templ = [IO.File]::ReadAllText($Glyphs) }
$tags = [OcrHelper]::ReadTags($src, $PR, $PG, $PB, $Tol, $YR, $YG, $YB, $YTol, $YBTol, $templ)
[IO.File]::WriteAllText($GlyphOut, $tags)
if ($Filter -eq 1) { [OcrHelper]::TagMask($src, $PR, $PG, $PB, $Tol, $YR, $YG, $YB, $YTol, $YBTol) }
# Tight crop of just the newest line of tags, read several ways (2x / 3x,
# dark-on-light and light-on-dark) - all results go into <OutBase>_line.txt
$line = [OcrHelper]::NewestTagLine($src, 6)
if ($line -ne $null) {
    $all = @()
    foreach ($sc in @(2, 3)) {
        foreach ($inv in @(0, 1)) {
            $lineOut = $Out -replace '\.png$', ('_line' + $sc + $inv + '.png')
            $lb = New-Object System.Drawing.Bitmap(($line.Width * $sc + 40), ($line.Height * $sc + 40))
            $gl = [System.Drawing.Graphics]::FromImage($lb)
            $gl.Clear([System.Drawing.Color]::White)
            $gl.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
            $gl.DrawImage($line, 20, 20, ($line.Width * $sc), ($line.Height * $sc))
            $gl.Dispose()
            if ($inv -eq 1) { [OcrHelper]::Invert($lb) }
            $lb.Save($lineOut, [System.Drawing.Imaging.ImageFormat]::Png)
            $lb.Dispose()
            $tmpBase = $OutBase + '_v'
            Invoke-Ocr $lineOut $tmpBase $Tess '--psm 7 -c tessedit_char_whitelist=[]AR0123456789'
            if (Test-Path ($tmpBase + '.txt')) {
                $t = [IO.File]::ReadAllText($tmpBase + '.txt').Trim()
                if ($t -ne '' -and $t -ne '!!NOOCR') { $all += ($t -replace '\s+', ' ') }
                Remove-Item ($tmpBase + '.txt')
            }
        }
    }
    $line.Dispose()
    [IO.File]::WriteAllText($OutBase + '_line.txt', ($all -join [Environment]::NewLine))
}
$big = New-Object System.Drawing.Bitmap(($W * $Scale), ($H * $Scale))
$g2 = [System.Drawing.Graphics]::FromImage($big)
$g2.Clear([System.Drawing.Color]::White)
$g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g2.DrawImage($src, 0, 0, $big.Width, $big.Height)
$g2.Dispose()
$src.Dispose()
$big.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$big.Dispose()
Invoke-Ocr $Out $OutBase $Tess '--psm 6 -c tessedit_char_whitelist=[]AR0123456789'
if ($DW -gt 0) {
    $d = New-Object System.Drawing.Bitmap($DW, $DH)
    $gd = [System.Drawing.Graphics]::FromImage($d)
    $gd.CopyFromScreen($DX, $DY, 0, 0, $d.Size)
    $gd.Dispose()
    [OcrHelper]::WhiteMask($d, 170)
    $db = New-Object System.Drawing.Bitmap(($DW * 3), ($DH * 3))
    $gd2 = [System.Drawing.Graphics]::FromImage($db)
    $gd2.Clear([System.Drawing.Color]::White)
    $gd2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $gd2.DrawImage($d, 0, 0, $db.Width, $db.Height)
    $gd2.Dispose()
    $d.Dispose()
    $db.Save($DOut, [System.Drawing.Imaging.ImageFormat]::Png)
    $db.Dispose()
    Invoke-Ocr $DOut $DOutBase $Tess '--psm 6'
}
    )"

    CSCode := "
    (
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

public static class OcrHelper
{
    [DllImport("user32.dll")]
    public static extern bool SetProcessDPIAware();

    // Purple R tag or yellow A tag pixels -> black, everything else -> white
    public static void TagMask(Bitmap bmp, int tr, int tg, int tb, int tol,
                               int yr, int yg, int yb, int ytol, int ybtol)
    {
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        BitmapData data = bmp.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        int bytes = Math.Abs(data.Stride) * bmp.Height;
        byte[] px = new byte[bytes];
        Marshal.Copy(data.Scan0, px, 0, bytes);

        for (int i = 0; i + 3 < bytes; i += 4)
        {
            int b = px[i], g = px[i + 1], r = px[i + 2];
            bool purple = Math.Abs(r - tr) <= tol && Math.Abs(g - tg) <= tol && Math.Abs(b - tb) <= tol;
            bool yellow = Math.Abs(r - yr) <= ytol && Math.Abs(g - yg) <= ytol && Math.Abs(b - yb) <= ybtol;
            byte v = (purple || yellow) ? (byte)0 : (byte)255;
            px[i] = v; px[i + 1] = v; px[i + 2] = v; px[i + 3] = 255;
        }

        Marshal.Copy(px, 0, data.Scan0, bytes);
        bmp.UnlockBits(data);
    }

    // Finds skill-tree level boxes whose text matches the given colour
    // (green "1/5" = not maxed, orange "MAX" = maxed).
    // Returns one "tag,x,y" line per box (centre of the text), top of screen first.
    public static string FindLevelBoxes(Bitmap bmp, int tr, int tg, int tb, int tol,
                                        int exX1, int exY1, int exX2, int exY2, int margin, string tag)
    {
        int W = bmp.Width, H = bmp.Height;
        BitmapData data = bmp.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = Math.Abs(data.Stride);
        byte[] px = new byte[stride * H];
        Marshal.Copy(data.Scan0, px, 0, px.Length);
        bmp.UnlockBits(data);

        const int C = 4;
        int cw = W / C + 1, ch = H / C + 1;
        int[] cells = new int[cw * ch];

        for (int y = 0; y < H; y++)
        {
            int row = y * stride;
            for (int x = 0; x < W; x++)
            {
                int i = row + x * 4;
                int b = px[i], g = px[i + 1], r = px[i + 2];
                if (Math.Abs(r - tr) <= tol && Math.Abs(g - tg) <= tol && Math.Abs(b - tb) <= tol)
                    cells[(x / C) + (y / C) * cw]++;
            }
        }

        bool[] seen = new bool[cw * ch];
        StringBuilder sb = new StringBuilder();
        Stack<int> st = new Stack<int>();

        for (int cy = 0; cy < ch; cy++)
        for (int cx = 0; cx < cw; cx++)
        {
            int start = cx + cy * cw;
            if (cells[start] == 0 || seen[start]) continue;

            seen[start] = true;
            st.Push(start);
            int x1 = cx, x2 = cx, y1 = cy, y2 = cy, n = 0;

            while (st.Count > 0)
            {
                int c = st.Pop();
                int a = c % cw, bb = c / cw;
                n += cells[c];
                if (a < x1) x1 = a; if (a > x2) x2 = a;
                if (bb < y1) y1 = bb; if (bb > y2) y2 = bb;

                // characters in "1/10" are a few px apart, so join cells up to 3 apart horizontally
                for (int dx = -3; dx <= 3; dx++)
                for (int dy = -1; dy <= 1; dy++)
                {
                    int u = a + dx, v = bb + dy;
                    if (u < 0 || v < 0 || u >= cw || v >= ch) continue;
                    int k = u + v * cw;
                    if (cells[k] > 0 && !seen[k]) { seen[k] = true; st.Push(k); }
                }
            }

            int bx1 = x1 * C, by1 = y1 * C, bx2 = x2 * C + C, by2 = y2 * C + C;
            int w = bx2 - bx1, h = by2 - by1;
            if (w < 12 || w > 80 || h < 6 || h > 24 || n < 15) continue;

            int mx = (bx1 + bx2) / 2, my = (by1 + by2) / 2;

            // must sit inside a dark level box
            if (!Dark(px, stride, W, H, bx1 - 5, my) || !Dark(px, stride, W, H, bx2 + 5, my) ||
                !Dark(px, stride, W, H, mx, by1 - 3) || !Dark(px, stride, W, H, mx, by2 + 2))
                continue;

            if (mx >= exX1 && mx <= exX2 && my >= exY1 && my <= exY2) continue;
            if (mx < margin || my < margin || mx > W - margin || my > H - margin) continue;

            sb.Append(tag).Append(',').Append(mx).Append(',').Append(my).Append('\n');
        }

        return sb.ToString();
    }

    // After TagMask (black tags on white): crop the bottom-most line of tags
    // (the newest chat message) with some padding. Returns null if none.
    public static Bitmap NewestTagLine(Bitmap bmp, int pad)
    {
        int W = bmp.Width, H = bmp.Height;
        BitmapData data = bmp.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = Math.Abs(data.Stride);
        byte[] px = new byte[stride * H];
        Marshal.Copy(data.Scan0, px, 0, px.Length);
        bmp.UnlockBits(data);

        int[] rowCount = new int[H];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
                if (px[y * stride + x * 4] < 128) rowCount[y]++;

        // bottom-most band of rows that contain tag pixels
        int bottom = -1;
        for (int y = H - 1; y >= 0; y--) if (rowCount[y] > 0) { bottom = y; break; }
        if (bottom < 0) return null;
        int top = bottom, gap = 0;
        for (int y = bottom - 1; y >= 0; y--)
        {
            if (rowCount[y] > 0) { top = y; gap = 0; }
            else if (++gap > 3) break;
        }

        int minX = W, maxX = -1;
        for (int y = top; y <= bottom; y++)
            for (int x = 0; x < W; x++)
                if (px[y * stride + x * 4] < 128) { if (x < minX) minX = x; if (x > maxX) maxX = x; }
        if (maxX < 0 || bottom - top < 4) return null;

        int cx = Math.Max(0, minX - pad), cy = Math.Max(0, top - pad);
        int cw = Math.Min(W - cx, maxX - minX + 1 + 2 * pad), ch = Math.Min(H - cy, bottom - top + 1 + 2 * pad);
        return bmp.Clone(new Rectangle(cx, cy, cw, ch), bmp.PixelFormat);
    }

    // ---------- Tag reader (no OCR) ----------
    // Finds the newest chat line's [A#] (yellow) and [R#] (purple) tags and
    // matches each digit against pixel templates ("d:w:h:bits;..." - learned
    // digits are added by the script). Output lines:
    //   R=33   A=2   (? = unknown digit, empty = tag not found)
    //   RP=w,h,bits;...   AP=...   (digit patterns, for learning)
    public static string ReadTags(Bitmap bmp, int pr, int pg, int pb, int ptol,
                                  int yr, int yg, int yb, int ytol, int ybtol, string templ)
    {
        int W = bmp.Width, H = bmp.Height;
        BitmapData data = bmp.LockBits(new Rectangle(0, 0, W, H), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        int stride = Math.Abs(data.Stride);
        byte[] px = new byte[stride * H];
        Marshal.Copy(data.Scan0, px, 0, px.Length);
        bmp.UnlockBits(data);

        bool[,] P = new bool[H, W], Y = new bool[H, W];
        for (int y = 0; y < H; y++)
            for (int x = 0; x < W; x++)
            {
                int i = y * stride + x * 4;
                int b = px[i], g = px[i + 1], r = px[i + 2];
                P[y, x] = Math.Abs(r - pr) <= ptol && Math.Abs(g - pg) <= ptol && Math.Abs(b - pb) <= ptol;
                Y[y, x] = Math.Abs(r - yr) <= ytol && Math.Abs(g - yg) <= ytol && Math.Abs(b - yb) <= ybtol;
            }

        // newest line = bottom-most band of rows with tag pixels (purple R OR
        // yellow A - at 0 rebirths the game only shows the [A#] tag)
        int bottom = -1;
        for (int y = H - 1; y >= 0 && bottom < 0; y--)
            for (int x = 0; x < W; x++) if (P[y, x] || Y[y, x]) { bottom = y; break; }
        if (bottom < 0) return "R=\nA=\nRP=\nAP=";
        int top = bottom, gap = 0;
        for (int y = bottom - 1; y >= 0; y--)
        {
            bool any = false;
            for (int x = 0; x < W; x++) if (P[y, x] || Y[y, x]) { any = true; break; }
            if (any) { top = y; gap = 0; } else if (++gap > 3) break;
        }

        List<string> rp = TagDigitPatterns(P, W, H, top, bottom);
        List<string> ap = TagDigitPatterns(Y, W, H, top, bottom);
        List<string[]> T = ParseTemplates(templ);

        // [A#] tag but no [R#] tag on the line = 0 rebirths
        string rText = (rp.Count == 0 && ap.Count > 0) ? "0" : MatchDigits(rp, T);
        return "R=" + rText + "\nA=" + MatchDigits(ap, T)
             + "\nRP=" + string.Join(";", rp.ToArray()) + "\nAP=" + string.Join(";", ap.ToArray());
    }

    static List<string> TagDigitPatterns(bool[,] M, int W, int H, int top, int bottom)
    {
        List<string> outp = new List<string>();
        int y0 = Math.Max(0, top - 3), y1 = Math.Min(H - 1, bottom + 3);
        List<int[]> small = new List<int[]>();
        int x = 0;
        while (x < W)
        {
            bool col = false;
            for (int y = y0; y <= y1; y++) if (M[y, x]) { col = true; break; }
            if (!col) { x++; continue; }
            int s = x;
            while (x < W)
            {
                bool c2 = false;
                for (int y = y0; y <= y1; y++) if (M[y, x]) { c2 = true; break; }
                if (!c2) break;
                x++;
            }
            int e = x - 1, gt = -1, gb = -1;
            for (int y = y0; y <= y1; y++)
                for (int xx = s; xx <= e; xx++)
                    if (M[y, xx]) { if (gt < 0) gt = y; gb = y; break; }
            if (gb < top || gt > bottom) continue;          // not on this line
            if (gb - gt + 1 > 11) continue;                 // brackets are taller - skip
            small.Add(new int[] { s, e, gt, gb });
        }
        if (small.Count < 2) return outp;
        // first glyph is the letter (A / R); digits follow until a big gap
        int last = small[0][1];
        for (int k = 1; k < small.Count; k++)
        {
            int[] g = small[k];
            if (g[0] - last > 12) break;
            last = g[1];
            int w = g[1] - g[0] + 1, h = g[3] - g[2] + 1;
            StringBuilder sb = new StringBuilder();
            for (int y = g[2]; y <= g[3]; y++)
                for (int xx = g[0]; xx <= g[1]; xx++) sb.Append(M[y, xx] ? '1' : '0');
            outp.Add(w + "," + h + "," + sb.ToString());
        }
        return outp;
    }

    static List<string[]> ParseTemplates(string templ)
    {
        List<string[]> T = new List<string[]>();
        if (templ == null) return T;
        foreach (string line in templ.Split(new char[] { ';', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries))
        {
            string[] f = line.Trim().Split(':');
            if (f.Length == 4) T.Add(f);
        }
        return T;
    }

    static string MatchDigits(List<string> pats, List<string[]> T)
    {
        StringBuilder sb = new StringBuilder();
        foreach (string p in pats)
        {
            string[] f = p.Split(',');
            int w1 = int.Parse(f[0]), h1 = int.Parse(f[1]);
            double best = 9, second = 9; string bestD = "?";
            foreach (string[] t in T)
            {
                double sc = Score(w1, h1, f[2], int.Parse(t[1]), int.Parse(t[2]), t[3]);
                if (sc < best) { if (t[0] != bestD) second = best; best = sc; bestD = t[0]; }
                else if (t[0] != bestD && sc < second) second = sc;
            }
            sb.Append(best <= 0.2 && second - best >= 0.15 ? bestD : "?");
        }
        return sb.ToString();
    }

    static double Score(int w1, int h1, string b1, int w2, int h2, string b2)
    {
        int ink1 = 0, ink2 = 0;
        foreach (char c in b1) if (c == '1') ink1++;
        foreach (char c in b2) if (c == '1') ink2++;
        int ink = Math.Max(1, Math.Max(ink1, ink2));
        double best = 1e9;
        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 1; dy++)
            {
                int Wd = Math.Max(w1, w2 + dx) + 2, Hd = Math.Max(h1, h2 + dy) + 2, mis = 0;
                for (int y = -1; y < Hd; y++)
                    for (int x = -1; x < Wd; x++)
                    {
                        bool a = x >= 0 && x < w1 && y >= 0 && y < h1 && b1[y * w1 + x] == '1';
                        int xx = x - dx, yy = y - dy;
                        bool c = xx >= 0 && xx < w2 && yy >= 0 && yy < h2 && b2[yy * w2 + xx] == '1';
                        if (a != c) mis++;
                    }
                double s = (double)mis / ink;
                if (s < best) best = s;
            }
        return best;
    }

    // Swap black and white (white text on black - how chat text normally looks)
    public static void Invert(Bitmap bmp)
    {
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        BitmapData data = bmp.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        int bytes = Math.Abs(data.Stride) * bmp.Height;
        byte[] px = new byte[bytes];
        Marshal.Copy(data.Scan0, px, 0, bytes);
        for (int i = 0; i + 3 < bytes; i += 4)
        {
            px[i] = (byte)(255 - px[i]); px[i + 1] = (byte)(255 - px[i + 1]); px[i + 2] = (byte)(255 - px[i + 2]); px[i + 3] = 255;
        }
        Marshal.Copy(px, 0, data.Scan0, bytes);
        bmp.UnlockBits(data);
    }

    // Light text -> black, everything else -> white (for reading button text)
    public static void WhiteMask(Bitmap bmp, int minv)
    {
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        BitmapData data = bmp.LockBits(rect, ImageLockMode.ReadWrite, PixelFormat.Format32bppArgb);
        int bytes = Math.Abs(data.Stride) * bmp.Height;
        byte[] px = new byte[bytes];
        Marshal.Copy(data.Scan0, px, 0, bytes);
        for (int i = 0; i + 3 < bytes; i += 4)
        {
            bool light = px[i] >= minv && px[i + 1] >= minv && px[i + 2] >= minv;
            byte v = light ? (byte)0 : (byte)255;
            px[i] = v; px[i + 1] = v; px[i + 2] = v; px[i + 3] = 255;
        }
        Marshal.Copy(px, 0, data.Scan0, bytes);
        bmp.UnlockBits(data);
    }

    static bool Dark(byte[] px, int stride, int W, int H, int x, int y)
    {
        if (x < 0 || y < 0 || x >= W || y >= H) return false;
        int i = y * stride + x * 4;
        return px[i] < 60 && px[i + 1] < 60 && px[i + 2] < 60;
    }
}
    )"

    SkillPSCode := "
    (
param([int]$W, [int]$H, [string]$Out, [string]$Cs, [int]$GR, [int]$GG, [int]$GB, [int]$MR, [int]$MG, [int]$MB, [int]$Tol, [int]$EX1, [int]$EY1, [int]$EX2, [int]$EY2)
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition ([IO.File]::ReadAllText($Cs))
[void][OcrHelper]::SetProcessDPIAware()
$bmp = New-Object System.Drawing.Bitmap($W, $H)
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.CopyFromScreen(0, 0, 0, 0, $bmp.Size)
$g.Dispose()
$res = [OcrHelper]::FindLevelBoxes($bmp, $GR, $GG, $GB, $Tol, $EX1, $EY1, $EX2, $EY2, 0, 'G')
$res += [OcrHelper]::FindLevelBoxes($bmp, $MR, $MG, $MB, $Tol, $EX1, $EY1, $EX2, $EY2, 0, 'M')
$bmp.Dispose()
[IO.File]::WriteAllText($Out, $res)
    )"

    BtnPSCode := "
    (
param([int]$X, [int]$Y, [int]$W, [int]$H, [string]$Out, [string]$Cs, [string]$Tess, [string]$OutBase)
. (Join-Path $PSScriptRoot 'roblox_ocrlib.ps1')
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition ([IO.File]::ReadAllText($Cs))
[void][OcrHelper]::SetProcessDPIAware()
$src = New-Object System.Drawing.Bitmap($W, $H)
$g = [System.Drawing.Graphics]::FromImage($src)
$g.CopyFromScreen($X, $Y, 0, 0, $src.Size)
$g.Dispose()
[OcrHelper]::WhiteMask($src, 170)
$big = New-Object System.Drawing.Bitmap(($W * 3), ($H * 3))
$g2 = [System.Drawing.Graphics]::FromImage($big)
$g2.Clear([System.Drawing.Color]::White)
$g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g2.DrawImage($src, 0, 0, $big.Width, $big.Height)
$g2.Dispose()
$src.Dispose()
$big.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$big.Dispose()
Invoke-Ocr $Out $OutBase $Tess '--psm 7'
    )"

    FileOpen(SkillPSFile, "w", "UTF-8").Write(SkillPSCode)
    FileOpen(BtnPSFile, "w", "UTF-8").Write(BtnPSCode)

    ; Read coloured text in a region (keeps only pixels near one colour)
    TextPSCode := "
    (
param([int]$X, [int]$Y, [int]$W, [int]$H, [int]$CR, [int]$CG, [int]$CB, [int]$Tol, [string]$Out, [string]$Cs, [string]$Tess, [string]$OutBase)
. (Join-Path $PSScriptRoot 'roblox_ocrlib.ps1')
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition ([IO.File]::ReadAllText($Cs))
[void][OcrHelper]::SetProcessDPIAware()
$src = New-Object System.Drawing.Bitmap($W, $H)
$g = [System.Drawing.Graphics]::FromImage($src)
$g.CopyFromScreen($X, $Y, 0, 0, $src.Size)
$g.Dispose()
[OcrHelper]::TagMask($src, $CR, $CG, $CB, $Tol, 0, 0, 0, -1, -1)
$big = New-Object System.Drawing.Bitmap(($W * 3), ($H * 3))
$g2 = [System.Drawing.Graphics]::FromImage($big)
$g2.Clear([System.Drawing.Color]::White)
$g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g2.DrawImage($src, 0, 0, $big.Width, $big.Height)
$g2.Dispose()
$src.Dispose()
$big.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$big.Dispose()
Invoke-Ocr $Out $OutBase $Tess '--psm 6'
    )"
    FileOpen(TextPSFile, "w", "UTF-8").Write(TextPSCode)

    ; Hotbar slot names -> TSV with word positions
    HotbarPSCode := "
    (
param([int]$X, [int]$Y, [int]$W, [int]$H, [string]$Out, [string]$Cs, [string]$Tess, [string]$OutBase)
. (Join-Path $PSScriptRoot 'roblox_ocrlib.ps1')
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition ([IO.File]::ReadAllText($Cs))
[void][OcrHelper]::SetProcessDPIAware()
$src = New-Object System.Drawing.Bitmap($W, $H)
$g = [System.Drawing.Graphics]::FromImage($src)
$g.CopyFromScreen($X, $Y, 0, 0, $src.Size)
$g.Dispose()
[OcrHelper]::WhiteMask($src, 170)
$big = New-Object System.Drawing.Bitmap(($W * 3), ($H * 3))
$g2 = [System.Drawing.Graphics]::FromImage($big)
$g2.Clear([System.Drawing.Color]::White)
$g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
$g2.DrawImage($src, 0, 0, $big.Width, $big.Height)
$g2.Dispose()
$src.Dispose()
$big.Save($Out, [System.Drawing.Imaging.ImageFormat]::Png)
$big.Dispose()
Invoke-OcrWords $Out $OutBase $Tess
    )"
    FileOpen(HotbarPSFile, "w", "UTF-8").Write(HotbarPSCode)
    FileOpen(PSFile, "w", "UTF-8").Write(PSCode)
    FileOpen(CSFile, "w", "UTF-8").Write(CSCode)

    ; Shared OCR functions for the scripts above. Uses the OCR built into
    ; Windows (Windows.Media.Ocr) unless a Tesseract path is passed in.
    ; (Backticks are literal in this block - needed for the WinRT type name.)
    OcrLibCode := "
    ( `
function Get-WinOcrResult([string]$Path) {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime
    $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
    $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Foundation.IAsyncOperation`1, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]
    $null = [Windows.Storage.Streams.RandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
    if ($engine -eq $null) { return $null }
    $awaiter = [WindowsRuntimeSystemExtensions].GetMember('GetAwaiter').Where({ $PSItem.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' }, 'First')[0]
    function Await($Task, $Type) { $awaiter.MakeGenericMethod($Type).Invoke($null, @($Task)).GetResult() }
    $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($Path)) ([Windows.Storage.StorageFile])
    $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $stream.Dispose()
    return $result
}

# Text, one line per line found -> <OutBase>.txt
function Invoke-Ocr([string]$Img, [string]$OutBase, [string]$Tess, [string]$TessArgs) {
    if ($Tess -and $Tess -ne 'none' -and (Test-Path $Tess)) {
        $a = @($Img, $OutBase) + ($TessArgs -split ' ')
        & $Tess @a 2>&1 | Out-Null
        return
    }
    try { $r = Get-WinOcrResult $Img } catch { $r = $null }
    if ($r -eq $null) { [IO.File]::WriteAllText($OutBase + '.txt', '!!NOOCR'); return }
    $lines = @($r.Lines | ForEach-Object { $_.Text })
    [IO.File]::WriteAllText($OutBase + '.txt', ($lines -join [Environment]::NewLine))
}

# Words with positions, "left<tab>width<tab>word" per line -> <OutBase>.words
function Invoke-OcrWords([string]$Img, [string]$OutBase, [string]$Tess) {
    $tab = [string][char]9
    $out = @()
    if ($Tess -and $Tess -ne 'none' -and (Test-Path $Tess)) {
        & $Tess $Img $OutBase --psm 6 tsv 2>&1 | Out-Null
        if (Test-Path ($OutBase + '.tsv')) {
            foreach ($line in [IO.File]::ReadAllLines($OutBase + '.tsv')) {
                $f = $line.Split([char]9)
                if ($f.Count -ge 12 -and $f[11].Trim() -ne '' -and $f[0] -ne 'level') { $out += ($f[6] + $tab + $f[8] + $tab + $f[11]) }
            }
        }
    } else {
        try { $r = Get-WinOcrResult $Img } catch { $r = $null }
        if ($r -ne $null) {
            foreach ($l in $r.Lines) { foreach ($w in $l.Words) {
                $out += ([string][int]$w.BoundingRect.X + $tab + [string][int]$w.BoundingRect.Width + $tab + $w.Text)
            } }
        }
    }
    [IO.File]::WriteAllText($OutBase + '.words', ($out -join [Environment]::NewLine))
}
    )"
    FileOpen(OcrLibFile, "w", "UTF-8").Write(OcrLibCode)

}

; ==========================================
; HOTKEYS
; ==========================================


F8::ExitApp()
