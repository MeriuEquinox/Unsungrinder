# Unsungrinder v1.0

An automation macro for the Roblox game **Unsungfield**.
Made by **Equinoxiiq** — questions / inquiries: **@equinoxi_q** on Discord.

## What it does

- **Case opening loop** – clicks the Cosmetics case open button, the results OK button and the ground (melee) automatically.
- **Rebirth / Ascension tracking** – reads your `[A#][R#]` chat tags straight from the screen (no OCR needed).
- **Two modes**
  - **Rebirth mode** – keeps Auto RB on and just keeps grinding.
  - **Ascension mode** – when you reach the rebirth requirement it turns Auto RB off and maxes your skill tree.
- **Skill tree auto-invest** – explores the whole tree and maxes every node (light-blue branch blocked).
- **Auto new game** – on Day 10 or lower (daytime), starts a fresh *Dawn of the Armageddon* server on Day 50 and deploys.
- **Keeps things in order** – re-equips your weapon (Shattered Sun / False Eclipse), reopens the case window, ticks "Skip animation", rejoins from the main menu.
- **M1 lock** – keeps your melee attack held while menus are open.
- **Discord webhook** – optional notifications for rebirths, ascensions, errors and more.
- Status window, full settings window, export / import of settings.

## Requirements

- Windows 10 or 11
- Roblox **fullscreen at 1920×1080** (other resolutions need positions adjusted in Settings → Advanced → Positions)
- That's it – `Unsungrinder.exe` does **not** need AutoHotkey installed.

## How to use

1. Download `Unsungrinder.exe` and put it in its **own folder** (e.g. Desktop\Unsungrinder) – it saves its settings next to itself.
2. Double-click it. If Windows SmartScreen appears, click **More info → Run anyway** (the file isn't code-signed).
3. In Roblox, open the Cosmetics → Case window.
4. Press **F1** to start / pause. **F8** exits.

### First run

- If the dashboard shows **A? / R?** or "?" digits: send a chat message, then go to **Settings → Test → Teach A / R** and type your current Ascension and Rebirth once (e.g. `2 33`). It remembers the digit shapes from then on.
- Check **Settings → General** – the click points are set for a 1920×1080 screen.
- Optional: paste a Discord webhook URL in **Settings → Advanced → Webhook**, then use **Settings → Test → Send test webhook**.

## Files it creates

| File | What |
|---|---|
| `unsungrinder_settings.ini` | Your settings (contains your webhook URL – don't share it; use Settings → Export instead) |
| `unsungrinder_glyphs.txt` | Learned digit shapes for reading A / R |

## Source

`Unsungrinder.ahk` is the full source (AutoHotkey v2). Run it with AutoHotkey v2 installed, or compile it yourself with Ahk2Exe.

## Disclaimer

Using macros may be against Roblox's or the game's rules. Use at your own risk.
